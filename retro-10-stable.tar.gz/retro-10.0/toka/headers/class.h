void word_class();
void macro_class();
void data_class();
void quote_class();

void string_getLength();
void string_grow();
void string_append();
void string_compare();

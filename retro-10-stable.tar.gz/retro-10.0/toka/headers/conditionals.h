void less_than();
void greater_than();
void equals();
void not_equals();

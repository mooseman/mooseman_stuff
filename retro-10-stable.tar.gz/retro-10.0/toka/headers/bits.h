void and();
void or();
void xor();
void lshift();
void rshift();

void make_literal();
void make_string_literal();

void fetch();
void store();
void fetch_char();
void store_char();
void copy();
void cell_size();
void char_size();

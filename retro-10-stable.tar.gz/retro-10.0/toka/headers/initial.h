void build_dictionary();


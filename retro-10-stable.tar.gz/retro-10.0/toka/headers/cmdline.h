void num_args();
void get_arg_list();
void build_arg_list(char *args[], long count);

void decompile(Inst *xt);
void see();

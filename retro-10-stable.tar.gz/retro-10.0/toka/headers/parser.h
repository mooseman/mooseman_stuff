void parse();
void get_token(char *s, long delim);
void to_number();
void to_string();
long include_file(char *s);
void include();
void needs();
void force_eof();

void vm_info();

void dot();
void emit();
void type();
void bye();

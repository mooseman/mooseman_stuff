/* $Id: _PDCLIB_test.h 262 2006-11-16 07:34:57Z solar $ */

/* Release $Name$ */

/* PDCLib testing suite <_PDCLIB_test.h>

   This file is part of the Public Domain C Library (PDCLib).
   Permission is granted to use, modify, and / or redistribute at will.
*/

/* -------------------------------------------------------------------------- */
/* Helper macros for test drivers                                             */
/* -------------------------------------------------------------------------- */

#include <stdio.h>

char const abcde[] = "abcde";
char const abcdx[] = "abcdx";

int NO_TESTDRIVER = 0;

#define BEGIN_TESTS   unsigned int rc = 0
#define TESTCASE( x ) if ( x ) {} \
                      else { rc += 1; printf( "Testcase failed: " __FILE__ ", line %d - " #x "\n", __LINE__ ); }
#define TEST_RESULTS  rc

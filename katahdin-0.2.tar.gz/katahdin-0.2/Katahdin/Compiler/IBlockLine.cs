namespace Katahdin.Compiler
{
    public interface IBlockLine
    {
    }
}
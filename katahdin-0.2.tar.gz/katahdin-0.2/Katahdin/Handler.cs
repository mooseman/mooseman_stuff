namespace Katahdin
{
    public delegate void Handler();
}
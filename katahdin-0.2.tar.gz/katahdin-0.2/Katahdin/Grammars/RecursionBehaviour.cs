namespace Katahdin.Grammars
{
    public enum RecursionBehaviour
    {
        None,
        Recursive,
        LeftRecursive,
        RightRecursive
    }
}
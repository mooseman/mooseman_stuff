namespace Katahdin.Grammars.Precedences
{
    public enum Relation
    {
        Lower,
        Equal,
        Higher
    }
}

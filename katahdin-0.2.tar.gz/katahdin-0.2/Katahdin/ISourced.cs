namespace Katahdin
{
    public interface ISourced
    {
        Source Source
        {
            get;
        }
    }
}
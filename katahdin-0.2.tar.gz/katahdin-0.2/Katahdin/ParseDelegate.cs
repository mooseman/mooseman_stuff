namespace Katahdin
{
    public delegate ParseTree ParseDelegate(Lexer lexer, ParserState state);
}

assert 14 + 2 == 16
assert 14 - 2 == 12
assert 14 * 2 == 28
assert 14 / 2 == 7
assert 2 * 3 + 4 == 10
assert 2 + 3 * 4 == 14
assert 2 * (3 + 4) == 14

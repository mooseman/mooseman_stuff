x = 0

for n in range(10):
    x = x + 1

assert x == 10

def test():
    return 14

x = test()
assert x == 14

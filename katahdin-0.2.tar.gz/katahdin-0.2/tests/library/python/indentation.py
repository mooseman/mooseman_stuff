x = 0
y = 0
z = 0

for n in range(10):
    x = x + 1
    y = y + 1
z = z + 1

assert x == 10
assert y == 10
assert z == 1

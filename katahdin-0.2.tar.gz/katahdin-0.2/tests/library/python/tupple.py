x = (1, 2)
(a, b) = x
assert a == 1
assert b == 2

def test():
    return (1, 2)

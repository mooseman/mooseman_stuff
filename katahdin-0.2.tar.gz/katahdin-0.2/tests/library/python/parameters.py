def test(x):
    x = x / 2
    return x

x = test(28)

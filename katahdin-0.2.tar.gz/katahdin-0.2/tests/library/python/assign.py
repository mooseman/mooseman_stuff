x = 14
assert x == 14

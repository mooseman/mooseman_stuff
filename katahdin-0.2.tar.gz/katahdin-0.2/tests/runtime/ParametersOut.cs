namespace Katahdin.Tests
{
    public static class ParametersOut
    {
        public static void Test(out int x, int y)
        {
            x = 14;
        }
    }
}

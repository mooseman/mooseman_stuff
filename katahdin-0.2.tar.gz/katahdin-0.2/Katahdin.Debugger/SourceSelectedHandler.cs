using System;

namespace Katahdin.Debugger
{
    public delegate void SourceSelectedHandler(Source source, bool highlightUpTo);
}

                               K A T A H D I N
                                       
                                 Chris Seaton
                                       
                            chris@chrisseaton.com
                         http://www.chrisseaton.com/
                         
Version 0.2, June 30th 2007

Requires

    Mono >= 1.2.3.1
    Gtk+ >= 2.6.10     }
    Gtk# >= 2.4.3      } only if you want to use the debugger

Compiling

    make

Installation

    After compiling you can use the executables where they are or copy the
    whole directory to somewhere else such as /usr/katahdin.
    
    You MUST set the $KATAHDIN variable to include the Katahdin directory, the
    library subdirectory, and the installed Mono library directory (usually
    something like /usr/lib/mono/2.0).

Getting Started

    Check the demos/ and tests/ subdirectories.

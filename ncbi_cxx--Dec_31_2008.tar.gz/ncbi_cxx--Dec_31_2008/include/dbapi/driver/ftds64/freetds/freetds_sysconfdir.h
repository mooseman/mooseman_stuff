#ifndef _WIN32
#    define FREETDS_SYSCONFDIR      "/etc"
#else
#    define FREETDS_SYSCONFDIR      "c:"
#endif

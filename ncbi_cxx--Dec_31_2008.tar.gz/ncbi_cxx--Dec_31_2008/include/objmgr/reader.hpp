#if defined __GNUG__
# warning This file is deprecated and will be removed soon.             \
    Please, update the include directive to:                            \
    #include <objtools/data_loaders/genbank/reader.hpp>
#endif

#include <objtools/data_loaders/genbank/reader.hpp>

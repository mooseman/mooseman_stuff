#if defined __GNUG__
# warning This file is deprecated and will be removed soon.             \
    Please, update the include directive to:                            \
        #include <objtools/edit/autodef_feature_clause.hpp>
#endif

#include <objtools/edit/autodef_feature_clause.hpp>

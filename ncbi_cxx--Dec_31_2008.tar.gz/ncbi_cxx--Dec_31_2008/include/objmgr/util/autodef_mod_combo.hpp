#if defined __GNUG__
# warning This file is deprecated and will be removed soon.             \
    Please, update the include directive to:                            \
        #include <objtools/edit/autodef_mod_combo.hpp>
#endif

#include <objtools/edit/autodef_mod_combo.hpp>

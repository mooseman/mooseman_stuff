#if defined __GNUG__
# warning This file is deprecated and will be removed soon.             \
    Please, update the include directive to:                            \
        #include <objtools/edit/autodef_source_desc.hpp>
#endif

#include <objtools/edit/autodef_source_desc.hpp>

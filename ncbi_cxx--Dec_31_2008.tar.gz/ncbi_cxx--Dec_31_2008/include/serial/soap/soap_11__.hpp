#include <serial/soap/soap_body.hpp>
#include <serial/soap/soap_detail.hpp>
#include <serial/soap/soap_envelope.hpp>
#include <serial/soap/soap_fault.hpp>
#include <serial/soap/soap_header.hpp>
#include <serial/soap/soap_11_module.hpp>

/* public domain by Paul Edwards */
void dumpbuf(unsigned char *buf, int len);
void dumplong(unsigned long x);


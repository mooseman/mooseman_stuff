/* public domain by Paul Edwards */

#include "support.h"

int int13x(union REGS *regsin, union REGS *regsout, struct SREGS *sregs);

/* released to the public domain */
int patmat(char *raw, char *pat);

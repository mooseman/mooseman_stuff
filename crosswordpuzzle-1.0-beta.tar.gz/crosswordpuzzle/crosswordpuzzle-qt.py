# -*- coding: UTF-8 -*-
"""
Qt4 UI Crossword Puzzle
Copyright 2007  Peter Gebauer
Licensed as Public Domain
"""
import sys
import logging
sys.path.append(".")
from optparse import OptionParser
from crossword.config import Config
from crossword.qtclient import *

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s'
                        )
    logging.getLogger("xw").setLevel(logging.DEBUG)
    parser = OptionParser(usage="%prog [options] [file])")
    parser.add_option("-e", "--edit",
                      action="store_true", dest="edit", default=False,
                      help="start crossword in edit mode")
    (options, args) = parser.parse_args()
    config = Config.load()
    config["startEdit"] = options.edit
    app = QCrosswordApplication(sys.argv, config, args and args[0] or None)
    app.exec_()


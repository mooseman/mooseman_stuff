# -*- coding: ascii -*-
"""
Crossword Puzzle - Qt Client GUI
Copyright 2007  Peter Gebauer
Licensed as Public Domain
"""

import os, time

from PyQt4 import QtGui, QtCore
from PyQt4.uic import loadUi

from crossword import *
from crossword.config import Config
from crossword.qtwidgets import *

PROGRAM = "CrosswordPuzzle"
VERSION = "1.0"
FILE_EXTENSION = "xw"

class QCrosswordApplication(QtGui.QApplication):

    def __init__(self, args, config = {}, loadPuzzle = None):
        QtGui.QApplication.__init__(self, args)
        self.window = QCrosswordWindow(config, loadPuzzle)
        self.window.show()


class QClueEditDialog(QtGui.QDialog):

    def __init__(self, config, x, y, puzzle, parent = None):
        QtGui.QDialog.__init__(self, parent)
        self.setModal(True)
        self.config = config
        self._x = x
        self._y = y
        self._puzzle = puzzle
        uiFile = os.path.normpath(
            os.path.expandvars(os.path.expanduser("%s/clue-edit-dialog.ui"%config.get("datapath", "./share"))))
        loadUi(uiFile, self)
        id1, wordAcross, clueAcross = puzzle.words().get((x, y, DIRECTION_ACROSS), (None, None, None))
        self.editAcross.setEnabled(bool(id1))
        id2, wordDown, clueDown = puzzle.words().get((x, y, DIRECTION_DOWN), (None, None, None))
        self.editDown.setEnabled(bool(id2))
        self.labelID.setText("%d"%(id1 or id2 or "?"))
        self.labelX.setText("%d"%x)
        self.labelY.setText("%d"%y)
        self.labelAcross.setText((wordAcross or "").replace(" ", "?"))
        self.labelDown.setText((wordDown or "").replace(" ", "?"))
        self.editAcross.setText(clueAcross or "")
        self.editDown.setText(clueDown or "")
        self.connect(self.pushButtonOK, QtCore.SIGNAL("clicked()"), self.updateClues)
        self.connect(self.pushButtonCancel, QtCore.SIGNAL("clicked()"), self.reject)

    def updateClues(self):
        if self.editAcross.isEnabled():
            clueAcross = unicode(self.editAcross.text()).strip()
            self._puzzle.setClue(self._x, self._y, DIRECTION_ACROSS, clueAcross)
        if self.editDown.isEnabled():
            clueDown = unicode(self.editDown.text()).strip()
            self._puzzle.setClue(self._x, self._y, DIRECTION_DOWN, clueDown)
        self.accept()


class QScoreDialog(QtGui.QDialog):

    def __init__(self, config, puzzle, parent = None):
        QtGui.QDialog.__init__(self, parent)
        self.scoringImplementations = {u"%s"%self.tr("ACPT"): ACPTScoring,
                                       u"%s"%self.tr("Time Attack"): TimeAttackScoring}
        self.puzzle = puzzle
        self.setModal(True)
        self.config = config
        uiFile = os.path.normpath(os.path.expandvars(os.path.expanduser("%s/score-dialog.ui"%config.get("datapath", "./share"))))
        loadUi(uiFile, self)
        for name, type_ in self.scoringImplementations.items():
            self.comboBox.addItem(name)
            if self.config.get("scoringImplementation") == name:
                self.comboBox.setCurrentIndex(self.comboBox.count() - 1)
        self.updateScores()
        self.connect(self.comboBox, QtCore.SIGNAL("currentIndexChanged (const QString&)"), self.updateScores)

    def updateScores(self):
        try:
            scores = self.puzzle.score(self.scoringImplementations[u"%s"%self.comboBox.currentText()])
        except ScoringException, e:
            QtGui.QMessageBox.information(
                self,
                self.tr("Could not calculate score"),
                self.tr("Puzzle solution is incomplete and scoring depends on it, sorry."))
            raise
        self.treeWidget.clear()
        self.treeWidget.setColumnCount(4)
        self.treeWidget.setHeaderLabels([self.tr("Name"), self.tr("Quantity"), self.tr("Points"), self.tr("Subtotal")])
        for name, qty, points in scores:
            if points:
                self.treeWidget.addTopLevelItem(QtGui.QTreeWidgetItem([self.tr(name),
                                                                       u"%d"%qty,
                                                                       u"%d"%points,
                                                                       u"%d"%(qty * points)]))
        for i in xrange(self.treeWidget.columnCount()):
            self.treeWidget.resizeColumnToContents(i)
        self.labelTotal.setText(u"%d"%scores.getTotal())
        self.labelMax.setText(u"%d"%scores.getMax())
        self.connect(self.pushButtonClose, QtCore.SIGNAL("clicked()"), self.close)
        

class QCrosswordWindow(QtGui.QMainWindow):

    def __init__(self, config = Config(), loadPuzzle = None, parent = None):
        QtGui.QMainWindow.__init__(self, parent)
        uiFile = os.path.normpath(os.path.expandvars(os.path.expanduser("%s/crossword-client.ui"%config.get("datapath", "./share"))))
        loadUi(uiFile, self)
        self.config = config
        self.puzzleWidget = QCrossword()
        if loadPuzzle:
            self.loadPuzzleFromFile(loadPuzzle)
        self.puzzleWidget.setEditMode(config.getBool("startEdit", False))
        self.puzzleWidget.setSquare(config.getBool("square", False))
        self.framePuzzle.setLayout(QtGui.QHBoxLayout())
        self.framePuzzle.layout().addWidget(self.puzzleWidget)
        self.puzzleWidget.setFocus()
        self._setupList(self.treeAcross)
        self._setupList(self.treeDown)
        self.splitter.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        self.resize(config.getInt("windowWidth") or self.width(),
                    config.getInt("windowHeight") or self.height())
        #self.actionSaveSettingsOnExit.setChecked(config.getBool("saveSettingsOnExit", False))
        self.update()
        self._connectAll()

    def _setupList(self, l):
        l.setColumnCount(3)
        l.hideColumn(2)
        l.setRootIsDecorated(False)
        l.setHeaderLabels([self.tr("ID"), self.tr("Clue")])
        l.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        l.setSortingEnabled(False)

    def _connectAll(self):
        self.connect(self.puzzleWidget, QtCore.SIGNAL("changed()"), self.update)
        self.connect(self.puzzleWidget, QtCore.SIGNAL("cursorMoved(int, int)"), self.updateListSelections)
        self.connect(self.puzzleWidget, QtCore.SIGNAL("letterTyped(int, int, const QString&)"), self.letterTyped)
        self.connect(self.puzzleWidget, QtCore.SIGNAL("timeUpdated(int, int)"), self.updateTime)
        self.connect(self.puzzleWidget, QtCore.SIGNAL("quitKeyPressed()"), self.done)
        self.connect(self.puzzleWidget, QtCore.SIGNAL("editClues(int, int)"), self.editClues)
        self.connect(self.treeAcross, QtCore.SIGNAL("itemClicked(QTreeWidgetItem *, int)"), self.listItemClicked)
        self.connect(self.treeDown, QtCore.SIGNAL("itemClicked(QTreeWidgetItem *, int)"), self.listItemClicked)
        self.connect(self.actionQuit, QtCore.SIGNAL("triggered()"), self.close)
        self.connect(self.actionNew, QtCore.SIGNAL("triggered()"), self.newPuzzle)
        self.connect(self.actionLoadFile, QtCore.SIGNAL("triggered()"), self.loadPuzzleFromFile)
        self.connect(self.actionSaveFile, QtCore.SIGNAL("triggered()"), self.savePuzzleToFile)        
        self.connect(self.actionStartRestart, QtCore.SIGNAL("triggered()"), self.startRestart)
        self.connect(self.actionDone, QtCore.SIGNAL("triggered()"), self.done)
        self.connect(self.actionEdit, QtCore.SIGNAL("triggered()"), self.editMode)        
        self.connect(self.actionEditClues, QtCore.SIGNAL("triggered()"), self.editClues)
        self.connect(self.actionSquare, QtCore.SIGNAL("triggered()"), self.squareToggle)
        self.connect(self.actionSettings, QtCore.SIGNAL("triggered()"), self.settings)
        self.connect(self.spinPar, QtCore.SIGNAL("valueChanged(int)"), self.changePar)
        self.connect(self.spinWidth, QtCore.SIGNAL("valueChanged(int)"), self.changePuzzleWidth)
        self.connect(self.spinHeight, QtCore.SIGNAL("valueChanged(int)"), self.changePuzzleHeight)

    def askQuestion(self, title, text):
        ret = QtGui.QMessageBox.question(self,                                         
                                         title,
                                         text,
                                         QtGui.QMessageBox.Ok,
                                         QtGui.QMessageBox.Cancel)
        if ret == QtGui.QMessageBox.Ok:
            return True
        return False

    def update(self):
        QtGui.QMainWindow.update(self)
        self.updateTime()
        self.updateInfo()
        self.updateListSelections()
        self.updateMenus()

    def updateMenus(self):
        edit = self.puzzleWidget.editMode()
        empty = not bool(self.puzzleWidget.words())
        self.actionEdit.setChecked(edit)
        self.actionEditClues.setEnabled(edit)
        self.groupInformation.setVisible(edit)
        self.groupBoxTimePar.setVisible(not edit)
        self.groupBoxCompletion.setVisible(not edit)
        self.actionStartRestart.setEnabled(not edit and not empty)
        self.actionDone.setEnabled(not edit and not empty)
        self.actionSquare.setChecked(self.puzzleWidget.square())
        self.actionSaveSettingsOnExit.setChecked(self.config.getBool("saveSettingsOnExit"))

    def updateInfo(self):
        if self.puzzleWidget.title():
            self.setWindowTitle("%s %s - %s"%(PROGRAM, VERSION, self.puzzleWidget.title()))
        else:
            self.setWindowTitle("%s %s"%(PROGRAM, VERSION))
        self.editTitle.setText(self.puzzleWidget.title() or "")
        self.spinPar.setValue(self.puzzleWidget.par())
        self.spinWidth.setValue(self.puzzleWidget.puzzleWidth())
        self.spinHeight.setValue(self.puzzleWidget.puzzleHeight())
        self.treeAcross.clear()
        self.treeDown.clear()
        for (x, y, direction), (id_, word, clue) in self.puzzleWidget.words().items():
            if direction == DIRECTION_ACROSS:
                item = QtGui.QTreeWidgetItem([u"%3d"%id_,
                                              u"%s"%clue,
                                              u"%d.%d"%(id_, DIRECTION_ACROSS)])
                self.treeAcross.addTopLevelItem(item)
            elif direction == DIRECTION_DOWN:
                item = QtGui.QTreeWidgetItem([u"%3d"%id_,
                                              u"%s"%clue,
                                              u"%d.%d"%(id_, DIRECTION_DOWN)])
                
                self.treeDown.addTopLevelItem(item)
        self.treeAcross.sortItems(0, QtCore.Qt.AscendingOrder)
        self.treeDown.sortItems(0, QtCore.Qt.AscendingOrder)
        for i in xrange(2):
            self.treeAcross.resizeColumnToContents(i)
            self.treeDown.resizeColumnToContents(i)

    def updateTime(self):
        t = self.puzzleWidget.time()
        self.labelTime.setText("%02d:%02d:%02d"%(t / 3600, t / 60, t % 60))
        t = self.puzzleWidget.par()
        if t:
            self.labelPar.setText("%02d:%02d:%02d"%(t / 3600, t / 60, t % 60))
        else:
            self.labelPar.setText(self.tr("N/A"))

    def updateProgress(self):
        self.progressCompletion.setValue(self.puzzleWidget.completed())

    def updateListSelections(self):
        self.treeAcross.clearSelection()
        self.treeDown.clearSelection()
        cx, cy = self.puzzleWidget.cursor()
        x, y = self.puzzleWidget.getStartPosition(cx, cy, DIRECTION_ACROSS)
        id_, word, clue = self.puzzleWidget.words().get((x, y, DIRECTION_ACROSS), (None, None, None))
        if id_:
            items = self.treeAcross.findItems(u"%d.%d"%(id_, DIRECTION_ACROSS), QtCore.Qt.MatchExactly, 2)
            for item in items:
                self.treeAcross.setItemSelected(item, True)
                self.treeAcross.scrollTo(self.treeAcross.indexFromItem(item))
        x, y = self.puzzleWidget.getStartPosition(cx, cy, DIRECTION_DOWN)
        id_, word, clue = self.puzzleWidget.words().get((x, y, DIRECTION_DOWN), (None, None, None))
        if id_:
            items = self.treeDown.findItems(u"%d.%d"%(id_, DIRECTION_DOWN), QtCore.Qt.MatchExactly, 2)
            for item in items:
                self.treeDown.setItemSelected(item, True)
                self.treeDown.scrollTo(self.treeDown.indexFromItem(item))

    def squareToggle(self):
        self.puzzleWidget.setSquare(not self.puzzleWidget.square())
        self.update()

    def listItemClicked(self, item, column):
        uid = item.data(2, QtCore.Qt.DisplayRole).toString()
        for (x, y, direction), (id_, solution, clue) in self.puzzleWidget.words().items():
            if uid == u"%d.%d"%(id_, direction):
                self.puzzleWidget.setCursor(x, y)
                self.puzzleWidget.setFocus()
                break
            
    def letterTyped(self, x, y, letter):
        if not self.puzzleWidget.editMode():
            self.updateProgress()

    def newPuzzle(self):
        if (self.puzzleWidget.readOnly()            
            or self.askQuestion(self.tr("New puzzle"),
                                self.tr("This will forfeit the current game!"))):
            self.puzzleWidget.setPuzzle(Puzzle())
            self.update()

    def loadPuzzleFromFile(self, fn = None):
        if not fn:
            fn = QtGui.QFileDialog.getOpenFileName(self,
                                                   self.tr("Load puzzle from file"),
                                                   self.config.getString("lastDir", "./share/puzzles"),
                                                   "*.%s"%FILE_EXTENSION,
                                                   )
        if fn:
            fn = str(fn)
            try:
                self.puzzleWidget.loadFromFile("%s"%fn)
                self.config["lastDir"] = os.path.normpath(os.path.dirname(fn))
                self.updateMenus()
            except PuzzleLoadException, v:
                QtGui.QMessageBox.critical(self,
                                           self.tr("Error while loading puzzle"),
                                           "%s"%v)
                raise

    def savePuzzleToFile(self, fn = None):
        if not fn:
            fn = QtGui.QFileDialog.getSaveFileName(self,
                                                   self.tr("Save puzzle to file"),
                                                   self.config.getString("lastDir", "./share/puzzles"),
                                                   "*.%s"%FILE_EXTENSION,
                                                   )
        if fn:
            fn = str(fn)
            if self.puzzleWidget.editMode():
                self.puzzleWidget.setTitle(u"%s"%self.editTitle.text())
                self.puzzleWidget.setPar(self.spinPar.value())
                self.puzzleWidget.setPuzzleWidth(self.spinWidth.value())
                self.puzzleWidget.setPuzzleHeight(self.spinHeight.value())
            try:
                self.puzzleWidget.saveToFile(fn, not self.puzzleWidget.editMode())
                self.config["lastDir"] = os.path.normpath(os.path.dirname(fn))
            except PuzzleLoadException, v:
                QtGui.QMessageBox.critical(self,
                                           self.tr("Error while saving puzzle"),
                                           "%s"%v)
                raise

    def startRestart(self):
        if (self.puzzleWidget.active        
            or self.askQuestion(self.tr("Start a new game"),
                                self.tr("This will forfeit the current game!"))):
            self.puzzleWidget.restart()
            self.puzzleWidget.setFocus()
            self.updateMenus()
    
    def done(self):
        if (self.puzzleWidget.active() and
            self.askQuestion(self.tr("Finish game"),
                             self.tr("This will end the current game and score it."))):
            self.puzzleWidget.stop()
            self.puzzleWidget.setShowSolution(True)
            self.updateMenus()
        dialog = QScoreDialog(self.config, self.puzzleWidget, self)
        dialog.exec_()

    def editMode(self):
        if self.puzzleWidget.editMode():
            self.puzzleWidget.setEditMode(False)
        else:
            if (not self.puzzleWidget.words()
                or self.askQuestion(self.tr("Enter edit mode"),
                                    self.tr("This will end the current game without scoring."))):
                self.puzzleWidget.setEditMode(True)
        self.updateMenus()

    def editClues(self, x = None, y = None):
        if x is None or y is None:
            x, y  = self.puzzleWidget.cursor()
        if (self.puzzleWidget.words().get((x, y, DIRECTION_ACROSS))
            or self.puzzleWidget.words().get((x, y, DIRECTION_DOWN))):
            dialog = QClueEditDialog(self.config, x, y, self.puzzleWidget, self)
            dialog.exec_()
        
    def settings(self):
        pass # edit settings
    
    def closeEvent(self, event):
        if (self.puzzleWidget.active()
            and not self.askQuestion(self.tr("Quit"),
                                     self.tr("This will forfeit the current game!"))):
            event.ignore()
            return
        #if self.config.getBool("saveSettingsOnExit") or self.actionSaveSettingsOnExit.isChecked():
        #    self.config["saveSettingsOnExit"] = self.actionSaveSettingsOnExit.isChecked() and "true" or "false"
        # Save settings on Exit?
        self.config["windowWidth"] = self.width()
        self.config["windowHeight"] = self.height()
        self.config["square"] = self.puzzleWidget.square() and "true" or "false"
        self.config["puzzleWidth"] = self.splitter.sizes()[0]
        self.config.save()

    def showEvent(self, event):
        w = self.config.getInt("puzzleWidth", 320)
        self.splitter.setSizes([w, self.splitter.width() - w])

    def changePuzzleWidth(self, w):
        if w < 3:
            w = 3
        elif w > 256:
            w = 256
        self.puzzleWidget.setPuzzleWidth(w)

    def changePuzzleHeight(self, h):
        if h < 3:
            h = 3
        elif h > 256:
            h = 256
        self.puzzleWidget.setPuzzleHeight(h)
        
    def changePar(self, par):
        if par >= 0 and par < 99999:
            self.puzzleWidget.setPar(par)

# -*- coding: ascii -*-
"""
Crossword Puzzle - Configuration parser and type
Copyright 2007  Peter Gebauer
Licensed as Public Domain
"""
import sys, os, logging

# For config paths, the last element is the user-specific one that
# will be used for saving settings
if sys.platform.startswith("linux"): # GNU/Linux style paths
    CONFIG_PATHS = ["/etc/default/crosswordpuzzle.conf", "./crosswordpuzzle.conf", "~/.crosswordpuzzle/config", ]
else: # Unknown, go for POSIX-style
    logging.getLogger("xw").warning("WARNING: platform '%s' is unknown, using default config paths\n"%sys.platform)
    CONFIG_PATHS = ["/etc/default/crosswordpuzzle.conf", "./crosswordpuzzle.conf", "~/.crosswordpuzzle/config"]


class ConfigParseException(Exception):
    """
    Raised when the configuratin parsing goes wrong.
    """
    

class Config(dict):

    def __init__(self, cnf = {}):
        dict.__init__(self)
        self.update(cnf)

    def getInt(self, k, default = 0):
        try:
            return int(self.get(k, 0))
        except (ValueError, TypeError):
            return default

    def getFloat(self, k, default = 0.0):
        try:
            return float(self.get(k, 0.0))
        except (ValueError, TypeError):
            return default

    def getString(self, k, default = ""):
        return self.get(k, "") or default

    def getBool(self, k, default = False):
        v = self.get(k)
        if v and str(v).strip().lower() in ("yes", "true", "1"):
            return True
        return False

    def __str__(self):
        return "\n".join(("%s = %s"%(k, v) for k, v in self.items()))

    def saveToFile(self, filename):
        f = file(filename, "w")
        f.write("%s"%self)
        f.close()

    def save(self):
        path = os.path.expandvars(os.path.expanduser(os.path.normpath(CONFIG_PATHS[-1])))
        dirname = os.path.dirname(path)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)
        self.saveToFile(path)
        logging.getLogger("xw").info("saved settings to '%s'"%path)

    @staticmethod
    def loadFromString(data):
        c = Config()
        if data:
            lineCount = 1
            for line in (l.strip() for l in data.split("\n")):
                if line and not line.startswith("#"):
                    spl = line.split("=", 1)
                    if len(spl) != 2:
                        raise ConfigParseException("syntax error on line %d"%lineCount)
                    c[spl[0].strip()] = spl[1].strip()
                    lineCount += 1
        return c

    @staticmethod
    def loadFromFile(filename):
        f = file(filename)
        data = f.read()
        f.close()
        return Config.loadFromString(data)

    @staticmethod
    def load():
        c = Config()
        for path in CONFIG_PATHS:
            path = os.path.expandvars(os.path.expanduser(os.path.normpath(path)))
            if os.path.isfile(path):
                c.update(Config.loadFromFile(path))
                logging.getLogger("xw").info("loaded config '%s'"%path)
        return c


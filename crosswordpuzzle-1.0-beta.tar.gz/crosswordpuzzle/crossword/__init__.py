# -*- coding: ascii -*-
"""
Crossword Puzzle
Copyright 2007  Peter Gebauer
Licensed as Public Domain
"""
import time
from xml.dom.minidom import parseString, Document, Element

DIRECTION_ACROSS = 10
DIRECTION_DOWN = 20
D_ACROSS = DIRECTION_ACROSS
D_DOWN = DIRECTION_DOWN

def normalizeElementList(l):
    """
    This function returns the first available element in an element list or
    None.
    """
    if l and l[0]:
        return l[0]
    return None

def textDirection(direction):
    """
    Get a textual representation of the numeric direction.
    """
    if not direction in (D_ACROSS, D_DOWN):
        raise ValueError("invalid direction")
    return ((direction == D_ACROSS and "across")
            or (direction == D_DOWN and "down"))

def createGrid(w, h, contents = None):
    """
    Returns a 2D list-based grid.
    """
    return [[contents for x in xrange(w)] for y in xrange(h)]    

def WordClueGenerator(words):
    """
    Return a generator that will yield tuples of (id_, x, y, direction, word, clue).
    """
    return ((id_, x, y, direction, word, clue) for (x, y, direction), (id_, word, clue) in words.items())


class PuzzleLoadException(Exception):
    """
    Error when loading the puzzle.
    """


class ScoringException(Exception):
    """
    Error when calculating the score.
    """
    

class Puzzle(object):
    """
    Holds unicode characters in two 2D matrices, it can
    represent either solution and answer as well as keep clues.
    """

    def __init__(self, **kwargs):
        """
        Available keyword arguments:
        width       int     Set the width.
        height      int     Set the height.
        fixedSize   bool    Make size immutable.
        time        int     How much time has been spent on the puzzle.
        """
        self._wordsCache = {}
        self.title = kwargs.get("title")
        self.par = kwargs.get("par", 0)
        self._startTime = 0
        self.stopTime = 0
        self.setTime(kwargs.get("time", 0))
        self._clues = {}
        self._width = kwargs.get("width", 15)
        self._height = kwargs.get("height", 15)
        self.fixedSize = kwargs.get("fixedSize", False)
        self._solution = createGrid(self.width, self.height)
        self._answer = createGrid(self.width, self.height)

    #
    # Properties
    #

    def setTime(self, t):
        self._startTime = time.time() - t
        self.stopTime = None

    time = property(lambda o: o.stopTime and o.stopTime - o._startTime or time.time() - o._startTime, setTime)

    def setSize(self, width, height):
        """
        Resizes or raises ValueError if fixedSize is True.
        """
        if self.fixedSize:
            raise ValueError("matrix has a fixed size")
        if width < 3 or height < 3:
            raise ValueError("invalid puzzle geometry")
        self._wordsCache = {}
        newMatrix = [[None for x in xrange(width)] for y in xrange(height)]
        for y in xrange(self._height):
            for x in xrange(self._width):
                if (y < len(newMatrix)
                    and x < len(newMatrix[y])
                    and y < len(self._solution)
                    and x < len(self._solution[y])):
                    newMatrix[y][x] = self._solution[y][x]
        self._solution = newMatrix
        newMatrix = [[None for x in xrange(width)] for y in xrange(height)]
        for y in xrange(self._height):
            for x in xrange(self._width):
                if (y < len(newMatrix)
                    and x < len(newMatrix[y])
                    and y < len(self._answer)
                    and x < len(self._answer[y])):
                    newMatrix[y][x] = self._answer[y][x]
        self._answer = newMatrix
        self._width = width
        self._height = height

    def setWidth(self, width):
        """
        Set a new width for the matrix.
        """
        self.setSize(width, self.height)

    def setHeight(self, height):
        """
        Set a new height for the matrix.
        """
        self.setSize(self.width, height)

    width = property(lambda o: o._width, lambda o, v: o.setWidth(v))
    height = property(lambda o: o._height, lambda o, v: o.setHeight(v))

    #
    # Make sure it behaves like a matrix.
    #

    def getAnswerChar(self, x, y):
        if x >= 0 and y >= 0 and x < self.width and y < self.height:
            if self[x, y] is None:
                return None
            return self._answer[y][x]
        raise IndexError("outside boundaries")

    def setAnswerChar(self, x, y, value):
        if x < 0 and y < 0 and x >= self.width and y >= self.height:
            raise IndexError("outside boundaries")
        if self[x, y] is None:
            self._answer[y][x] = None
        else:
            self._answer[y][x] = value and unicode(value[0]) or None

    def getChar(self, x, y):
        if x < 0 and y < 0 and x >= self.width and y >= self.height:
            raise IndexError("outside boundaries")
        return self[x, y]

    def setChar(self, x, y, value):
        self[x, y] = value

    def __getitem__(self, (x, y)):
        if x < 0 and y < 0 and x >= self.width and y >= self.height:
            raise IndexError("outside boundaries")
        return self._solution[y][x]

    def __setitem__(self, (x, y), v):
        if x < 0 and y < 0 and x >= self.width and y >= self.height:
            raise IndexError("outside boundaries")
        self._solution[y][x] = v and unicode(v[0]) or None
        self._wordsCache = {}
                
    def __str__(self):
        ret = ["Title: %s"%self.title,
               "Par: %d"%self.par,
               "Size: %dx%d"%(self.width, self.height)]
        for y in xrange(len(self._solution)):
            ret.append("".join((c or "#" for c in self._solution[y])))
        return "\n".join(ret)

    #
    # Methods
    #

    def clear(self):
        """
        Clear the answer grid.
        """
        self._answer = createGrid(self.width, self.height)

    def _getString(self, matrix, x, y, direction):
        """
        Return a string from a given position and direction in specified matrix.
        You probably want to use getSolutionString or getAnswerString.
        """
        ret = []
        while x >= 0 and y >= 0 and x < self.width and y < self.height:
            char = matrix[y][x]
            if char is None:
                if matrix == self._solution:
                    break
                else:
                    char = u" "
            if char and not self[x, y] is None:
                ret.append(char)
            if direction == DIRECTION_ACROSS:
                x += 1
            elif direction == DIRECTION_DOWN:
                y += 1
            else:
                raise ValueError("invalid direction")
        return u"".join(ret)

    def getString(self, x, y, direction):
        """
        Get longest, possible, uninterrupted string from the solution grid.
        """
        return self._getString(self._solution, x, y, direction)

    def getAnswerString(self, x, y, direction):
        """
        Get longest, possible, uninterrupted string from the answer grid.
        """
        return self._getString(self._answer, x, y, direction)

    def _setString(self, matrix, x, y, direction, value, clue = None):
        """
        Set a string in a given position and direction in specified matrix.
        You probably want to use setSolutionString or setAnswerString.
        """
        if matrix == self._solution:
            self._wordsCache = {}
        if (x < 0 or y < 0
            or (direction == DIRECTION_ACROSS and x + len(value) > self.width)
            or (direction == DIRECTION_DOWN and y + len(value) > self.height)):
            raise IndexError("string out of bounds")
        if clue:
            self._clues[(x, y, direction)] = unicode(clue)
        for char in (c and unicode(c[0]) or None for c in value):
            if matrix == self._solution or (char.strip() and not self[x, y] is None):
                matrix[y][x] = char
            if direction == DIRECTION_ACROSS:
                x += 1
            elif direction == DIRECTION_DOWN:
                y += 1
            else:
                raise ValueError("invalid direction")

    def setString(self, x, y, direction, value, clue = None):
        """
        Set a string in the solution matrix. Only boundary checks are applied.
        """
        return self._setString(self._solution, x, y, direction, value, clue)

    def setAnswerString(self, x, y, direction, value):
        """
        Set a string in the answer matrix. Will check against the solution
        to make sure the answer fits the crossword.
        """
        return self._setString(self._answer, x, y, direction, value)

    def getWords(self):
        """
        Return all possible words from the solution matrix. The return value is
        a complex dictionary data structure.
        Keys: (x, y, direction)
        Values: (ID, solution, clue)
        Solution might be only spaces and clue might be None.
        You can use the various generator functions to filter out specific values
        from the word data structure. (WordClueGenerator, for instance)
        """
        if not self._wordsCache:
            self._wordsCache = {}
            id_ = 1
            for y in xrange(self.height):
                for x in xrange(self.width):
                    s = self.getString(x, y, DIRECTION_DOWN)
                    if len(s) >= 3 and (y == 0 or self[x, y - 1] is None):
                        self._wordsCache[(x, y, DIRECTION_DOWN)] = (id_, s, self._clues.get((x, y, DIRECTION_DOWN)))
                    s = self.getString(x, y, DIRECTION_ACROSS)
                    if len(s) >= 3 and (x == 0 or self[x - 1, y] is None):
                        self._wordsCache[(x, y, DIRECTION_ACROSS)] = (id_, s,
                                                                      self._clues.get((x, y, DIRECTION_ACROSS)))
                    if (self._wordsCache.has_key((x, y, DIRECTION_DOWN))
                        or self._wordsCache.has_key((x, y, DIRECTION_ACROSS))):
                        id_ += 1
            for (x, y, direction), clue in self._clues.items():
                if not self._wordsCache.has_key((x, y, direction)):
                    del self._clues[(x, y, direction)]
        return self._wordsCache

    def getStartPosition(self, x, y, direction):
        """
        Takes any position and finds the start of that word (solution grid)
        and returns a tuple containing x and y values.
        """
        if direction == DIRECTION_ACROSS:
            i = x
            while i > 0 and self[i, y]:
                i -= 1
            return i != 0 and i + 1 or i, y
        elif direction == DIRECTION_DOWN:
            i = y
            while i > 0 and self[x, i]:
                i -= 1
            return x, i != 0 and i + 1 or i
        raise ValueError("invalid direction")

    def getClue(self, *idOrKey):
        """
        Takes either one, two or three arguments being either only the ID or x, y, direction where
        direction is optional.
        If three arguments are given, a single clue will be returned in unicode. All other combinations
        of arguments will return in a two-element list containing the clue for across and the clue
        for down.
        Failing to find a clue will return None.
        Examples:
        puzzle.getClue(x, y, direction), puzzle.getClue(x, y) or puzzle.getClue(ID)
        """
        if len(idOrKey) == 3:
            return self._clues.get(idOrKey)
        elif len(idOrKey) >= 1 and len(idOrKey) <= 2:
            ret = [None, None]
            for (x, y, direction), (id_, word, clue) in self.getWords().items():
                if ((len(idOrKey) == 1 and id_ == idOrKey[0])
                    or (len(idOrKey) == 2 and (x, y) == idOrKey)):
                    if direction == DIRECTION_ACROSS:
                        ret[0] = self._clues.get((x, y, direction))
                    elif direction == DIRECTION_DOWN:
                        ret[1] = self._clues.get((x, y, direction))
            return ret
        else:
            raise TypeError("getClue() takes between 1 and 3 arguments (%d given)"%len(idOrKey))
        return None

    def setClue(self, x, y, direction, clue):
        """
        Set a clue for the given position and direction.
        """
        self._clues[(x, y, direction)] = unicode(clue)
        self._wordsCache = {}

    def _getCharacterCount(self, matrix):
        ret = []
        for y in xrange(self.height):
            for x in xrange(self.width):
                if not matrix[y][x] is None:
                    ret.append(matrix[y][x])
        return len(ret)

    def getCharacterCount(self):
        return self._getCharacterCount(self._solution)

    def getAnswerCharacterCount(self):
        return self._getCharacterCount(self._answer)

    @staticmethod
    def loadFromString(data):
        doc = parseString(data)
        ePuzzle = normalizeElementList(doc.getElementsByTagName("puzzle"))
        if not ePuzzle:
            raise PuzzleLoadException("no 'puzzle' element found")
        args = {}
        if ePuzzle.getAttribute("title"):
            args["title"] = ePuzzle.getAttribute("title")
        if ePuzzle.getAttribute("par"):
            try:
                args["par"] = int(ePuzzle.getAttribute("par"))
            except (ValueError, TypeError):
                raise PuzzleLoadException("puzzle 'par' attribute must be integer")
        if ePuzzle.getAttribute("time"):
            try:
                args["time"] = int(ePuzzle.getAttribute("time"))
            except (ValueError, TypeError):
                raise PuzzleLoadException("puzzle 'time' attribute must be integer")
        if ePuzzle.getAttribute("width"):
            try:
                args["width"] = int(ePuzzle.getAttribute("width"))
            except (ValueError, TypeError):
                raise PuzzleLoadException("puzzle 'width' attribute must be integer")
        if ePuzzle.getAttribute("height"):
            try:
                args["height"] = int(ePuzzle.getAttribute("height"))
            except (ValueError, TypeError):
                raise PuzzleLoadException("puzzle 'height' attribute must be integer")
        p = Puzzle(**args)
        eWords = ePuzzle.getElementsByTagName("word")
        for eWord in eWords:
            if eWord.getAttribute("x"):
                try:
                    x = int(eWord.getAttribute("x"))
                except (ValueError, TypeError):
                    raise PuzzleLoadException("word 'x' attribute must be integer; %s"%eWord.toxml())
            else:
                raise PuzzleLoadException("word is missing 'x' attribute; %s"%eWord.toxml())
            if eWord.getAttribute("y"):
                try:
                    y = int(eWord.getAttribute("y"))
                except (ValueError, TypeError):
                    raise PuzzleLoadException("word 'y' attribute must be integer; %s"%eWord.toxml())
            else:
                raise PuzzleLoadException("word is missing 'y' attribute; %s"%eWord.toxml())
            if eWord.hasAttribute("clue"):
                clue = eWord.getAttribute("clue")
            else:
                raise PuzzleLoadException("word is missing 'clue' attribute; %s"%eWord.toxml())
            eDirection = eWord.getAttribute("direction")
            if (u"ACROSS".startswith(eDirection.upper())
                or u"HORIZONTAL".startswith(eDirection.upper())
                or eDirection == u"%s"%DIRECTION_ACROSS):
                direction = DIRECTION_ACROSS
            elif (u"DOWN".startswith(eDirection.upper())
                  or u"VERTICAL".startswith(eDirection.upper())
                  or eDirection == u"%s"%DIRECTION_DOWN):
                direction = DIRECTION_DOWN
            else:
                raise PuzzleLoadException("word has invalid direction; %s"%eWord.toxml())
            solution = eWord.getAttribute("solution")
            if not solution:
                try:
                    length = int(eWord.getAttribute("length"))
                except (ValueError, TypeError):
                    raise PuzzleLoadException("word 'length' attribute must be integer; %s"%eWord.toxml())
                solution = " " * length
            try:
                p.setString(x, y, direction, solution, clue.strip() or None)
            except IndexError:
                raise PuzzleLoadException("word solution outside matrix boundaries; %s"%eWord.toxml())
            answer = eWord.getAttribute("answer")
            if answer.strip():
                p.setAnswerString(x, y, direction, answer)
        return p

    @staticmethod
    def loadFromFile(filename):
        f = file(filename)
        data = f.read()
        f.close()
        return Puzzle.loadFromString(data)
    
    def saveToString(self, includeAnswers = False):
        doc = Document()
        ePuzzle = doc.appendChild(doc.createElement("puzzle"))
        if self.title:
            ePuzzle.setAttribute("title", u"%s"%self.title)
        ePuzzle.setAttribute("width", u"%d"%self.width)
        ePuzzle.setAttribute("height", u"%d"%self.height)
        if self.par:
            ePuzzle.setAttribute("par", u"%d"%self.par)
        if includeAnswers:
            ePuzzle.setAttribute("time", u"%d"%self.time)
        for (x, y, direction), (id_, word, clue) in self.getWords().items():
            eWord = ePuzzle.appendChild(doc.createElement("word"))
            eWord.setAttribute("x", u"%d"%x)
            eWord.setAttribute("y", u"%d"%y)
            eWord.setAttribute("direction", u"%s"%textDirection(direction))
            eWord.setAttribute("solution", u"%s"%word)
            eWord.setAttribute("clue", u"%s"%clue)
            if includeAnswers:
                s = self.getAnswerString(x, y, direction)
                if s:
                    eWord.setAttribute("answer", u"%s"%s)
        output = doc.toprettyxml(u"\t", u"\n", "UTF-8")
        return output

    def saveToFile(self, filename, includeAnswers = False):
        data = self.saveToString(includeAnswers)
        f = file(filename, "w")
        f.write(data)
        f.close()


class Scores(list):

    def __init__(self, puzzle):
        list.__init__(self)
        self.puzzle = puzzle
        self.updateScores()

    def getWords(self):
        return [word for (x, y, direction), (id_, word, clue) in self.puzzle.getWords().items()]

    def getNumWords(self):
        return len(self.getWords())

    def getCorrectWords(self):
        ret = []
        for (x, y, direction), (id_, word, clue) in self.puzzle.getWords().items():
            s = self.puzzle.getAnswerString(x, y, direction)
            if not word or not word.strip():
                raise ScoringException("incomplete solution")
            if s == word:
                ret.append(word)
        return ret

    def getNumCorrectWords(self):
        return len(self.getCorrectWords())

    def getIncorrectWords(self):
        ret = []
        for (x, y, direction), (id_, word, clue) in self.puzzle.getWords().items():
            s = self.puzzle.getAnswerString(x, y, direction)
            if not word or not word.strip():
                raise ScoringException("incomplete solution")
            if s != word:
                ret.append(word)
        return ret

    def getNumIncorrectWords(self):
        return len(self.getIncorrectWords())

    def getNumIncorrectChars(self):
        errors = 0
        for y in xrange(self.puzzle.height):
            for x in xrange(self.puzzle.width):
                if self.puzzle[x, y] and not self.puzzle[x, y].strip():
                    raise ScoringException("incomplete solution")
                elif self.puzzle[x, y] and self.puzzle[x, y] != self.puzzle.getAnswerChar(x, y):
                    errors += 1
        return errors

    def updateScores(self):
        pass

    def getTotal(self):
        total = 0
        for name, quantity, points in self:            
            total += quantity * points
        return total

    def subTotal(self, key):
        return self[key][0] * self[key][1]

    def getMax(self):
        return 0

    def getPlayedTime(self):
        return self.puzzle.time
 
    def getUnderPar(self):
        return self.puzzle.par - self.getPlayedTime()
        
        


class ACPTScoring(Scores):
 
    def updateScores(self):
        del self[:]
        self.append(("Correct words", self.getNumCorrectWords(), 10))
        minutes = int(self.getUnderPar() / 60) + 1
        if minutes < 0:
            minutes = 0
        errors = self.getNumIncorrectChars()
        bonus = (minutes * 25) - (errors * 25)
        self.append(("Time bonus", minutes, 25))
        self.append(("Error penalty", errors, -25))
        self.append(("Negative bonus safety", bonus < 0 and 1 or 0, bonus < 0 and -bonus or 0))
        self.append(("Award bonus", errors == 0 and 1 or 0, 150))
        
    def getMax(self):
        total = self.getNumWords() * 10
        total += (self.puzzle.par / 60) * 25
        total += 150
        return total


class TimeAttackScoring(Scores):
 
    def updateScores(self):
        del self[:]
        correct = sum((len(w) for w in self.getCorrectWords()))
        seconds = int(self.getPlayedTime())
        self.append(("Letters in every correct word", correct, 10))
        self.append(("Time penalty", seconds, -1))
        
    def getMax(self):
        return sum((len(w) for w in self.getWords())) * 10

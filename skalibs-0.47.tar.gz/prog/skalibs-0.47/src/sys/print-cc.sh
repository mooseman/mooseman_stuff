cc="`head -n 1 $1`"
cat warn-auto.sh
exec cat <<EOF
exec $cc -c "\$1"
EOF

/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "dns_transmit.h"

int dns_resolvconfrewrite (stralloc *out)
{
  if (!dns_resolvconfrewriteit(&dns_rcrw_info_here)) return -1 ;
  out->len = 0 ;
  if (!stralloc_catb(out, dns_rcrw_info_here.rules.s, dns_rcrw_info_here.rules.len)) return -1 ;
  return 0 ;
}

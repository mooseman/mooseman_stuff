/* Public domain. */

#ifndef DNS_H
#define DNS_H

#include "dns_helper.h"
#include "dns_transmit.h"

#endif

/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "dns.h"

int dns_name4 (stralloc *out, char const *ip)
{
  char name[DNS_NAME4_DOMAIN] ;
  register int r ;
  dns_name4_domain(name, ip) ;
  if (dns_resolve(name, DNS_T_PTR) == -1) return -1 ;
  r = dns_name_packet(out, dns_resolve_tx.packet, dns_resolve_tx.packetlen) ;
  dns_transmit_free(&dns_resolve_tx) ;
  return r ;
}

/* Public domain. */

/* MT-unsafe */

#include "dns_transmit.h"

struct dns_rcip_info dns_rcip_info_here = DNS_RCIP_INFO_ZERO ;

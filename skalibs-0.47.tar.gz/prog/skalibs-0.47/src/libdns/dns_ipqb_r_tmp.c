/* Public domain. */

#include "stralloc.h"
#include "dns_transmit.h"

int dns_ip4_qualifyb_r_tmp (stralloc *out, stralloc *fqdn, char const *in, unsigned int inlen, struct dns_rcrw_info *dr, stralloc *tmp)
{
  if (!dns_resolvconfrewriteit_tmp(dr, tmp)) return -1 ;
  return dns_ip4_qualify_rulesb(out, fqdn, in, inlen, dr->rules.s, dr->rules.len) ;
}

/* Public domain. */

#include "stralloc.h"
#include "dns_transmit.h"

int dns_ip4_qualify_rules (stralloc *out, stralloc *fqdn, stralloc const *in, stralloc const *rules)
{
  return dns_ip4_qualify_rulesb(out, fqdn, in->s, in->len, rules->s, rules->len) ;
}

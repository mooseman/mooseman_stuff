/* Public domain. */

#include "dns_helper.h"

unsigned int dns_domain_length (char const *dn)
{
  char const *x = dn ;
  unsigned char c ;

  while ((c = *x++)) x += (unsigned int) c ;
  return x - dn ;
}

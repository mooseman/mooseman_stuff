/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "skamisc.h"
#include "dns_transmit.h"

int dns_ip4_qualifyb (stralloc *out, stralloc *fqdn, char const *in, unsigned int inlen)
{
  return dns_ip4_qualifyb_r_tmp(out, fqdn, in, inlen, &dns_rcrw_info_here, &satmp) ;
}

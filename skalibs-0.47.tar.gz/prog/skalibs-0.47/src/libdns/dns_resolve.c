/* Public domain. */

/* MT-unsafe */

#include "dns_transmit.h"

struct dns_transmit dns_resolve_tx = DNS_TRANSMIT_ZERO ;

int dns_resolve (char const *q, char const *qtype)
{
  return dns_resolve_r(q, qtype, &dns_resolve_tx, &dns_rcip_info_here) ;
}

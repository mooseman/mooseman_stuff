/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "dns.h"

int dns_ip4 (stralloc *out, stralloc const *fqdn)
{
  return dns_ip4b(out, fqdn->s, fqdn->len) ;
}

/* Public domain. */

#include <sys/types.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include "djbunix.h"
#include "pflocal.h"
#include "webipc.h"

int ipc_stream ()
{
  int s = socket(PF_LOCAL, SOCK_STREAM, 0) ;
  if (s == -1) return -1 ;
  if (ndelay_on(s) == -1) { fd_close(s) ; return -1 ; }
  return s ;
}

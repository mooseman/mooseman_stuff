/* Public domain. */

#include <sys/types.h>
#include <sys/time.h>
#include "tai.h"

void taia_now (struct taia *a)
{
  struct timeval now ;
  gettimeofday(&now, 0) ;
  taia_from_timeval(a, &now) ;
  a->nano += 500 ;
}

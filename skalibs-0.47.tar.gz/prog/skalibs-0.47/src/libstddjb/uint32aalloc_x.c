/* Public domain. */

#include "uint32alloc.h"
#include "uint32aalloc.h"

GEN_ALLOC_EXTENDED_DEFS(uint32aalloc, uint32alloc, s, len, a)

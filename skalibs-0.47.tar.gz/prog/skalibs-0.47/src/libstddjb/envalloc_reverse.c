/* Public domain. */

#include "gen_alloc.h"
#include "envalloc.h"

GEN_ALLOC_reverse(envalloc, char const *, s, len, a)

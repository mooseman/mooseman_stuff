/* Public domain. */

#include "bytestr.h"
#include "stralloc.h"

int stralloc_inserts (stralloc *to, unsigned int offset, char const *s)
{
  return stralloc_insertb(to, offset, s, str_len(s)) ;
}

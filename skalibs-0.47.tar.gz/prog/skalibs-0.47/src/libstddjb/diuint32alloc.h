/* Public domain. */

#ifndef DIUINT32ALLOC_H
#define DIUINT32ALLOC_H

#include "gen_alloc.h"
#include "diuint32.h"

GEN_ALLOC_PROTOTYPES(diuint32alloc, diuint32, s, len, a)

#define DIUINT32ALLOC_ZERO GEN_ALLOC_ZERO

#endif

/* Public domain. */

#include "stralloc.h"
#include "skamisc.h"

stralloc satmp = STRALLOC_ZERO ;

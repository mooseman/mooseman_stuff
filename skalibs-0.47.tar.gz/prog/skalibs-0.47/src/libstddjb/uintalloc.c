/* Public domain. */

#undef USE_DJBALLOC
#include "gen_alloc.h"
#include "uintalloc.h"

GEN_ALLOC_BASE_DEFS(uintalloc, unsigned int, s, len, a, 256)

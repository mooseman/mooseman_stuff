/* Public domain. */

#include "tai.h"
#include "caltimedate.h"

/* XXX: breaks tai encapsulation */

void caltime_tai (struct caltime const *ct, struct tai *t)
{
  /* XXX: check for overflow? */
  long day = caldate_mjd(&ct->date) ;
  long s = (ct->hour * 60 + ct->minute - ct->offset) * 60 + ct->second ;
  t->x = day * 86400ULL + 4611686014920671114ULL + (long long) s ;

  leapsecs_add(t, ct->second == 60) ;
}

/* Public domain. */

#ifndef LEAPSECS_INTERNAL_H
#define LEAPSECS_INTERNAL_H

#include "tai.h"

extern struct tai *leapsecs ;
extern unsigned int leapsecs_num ;

#endif

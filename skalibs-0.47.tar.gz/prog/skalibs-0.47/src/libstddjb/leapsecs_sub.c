/* Public domain. */

/* MT-unsafe */

#include "tai.h"
#include "caltimedate.h"
#include "leapsecs_internal.h"

/* XXX: breaks tai encapsulation */

int leapsecs_sub (struct tai *t)
{
  unsigned int i = 0 ;
  uint64 u = t->x ;
  unsigned int s = 0 ;
  if (leapsecs_init() == -1) return 0 ;

  for (; i < leapsecs_num ;i++)
  {
    if (u < leapsecs[i].x) break ;
    ++s ;
    if (u == leapsecs[i].x) { t->x = u - s ; return 1 ; }
  }

  t->x = u - s ;
  return 0 ;
}

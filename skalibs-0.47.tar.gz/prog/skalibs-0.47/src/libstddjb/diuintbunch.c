/* Public domain. */

#include "diuint.h"
#include "diuintalloc.h"
#include "gen_bunch.h"
#include "diuintbunch.h"

GEN_BUNCH_DEFS(diuintbunch, diuintalloc, diuint, 64, 16)

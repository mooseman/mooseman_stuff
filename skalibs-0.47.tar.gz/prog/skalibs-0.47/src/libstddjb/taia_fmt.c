/* Public domain. */

#include "fmtscan.h"
#include "tai.h"

unsigned int taia_fmt (char *s, struct taia const *a)
{
  char pack[TAIA_PACK] ;
  taia_pack(pack, a) ;
  return fmt_ucharn(s, pack, TAIA_PACK) ;
}

/* Public domain. */

#include "uint16.h"
#include "fmtscan-internal.h"

SCANU0(uint16, uint16, 65535)

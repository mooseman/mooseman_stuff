/* Public domain. */

#ifndef UINTBUNCH_H
#define UINTBUNCH_H

#include "uintalloc.h"
#include "gen_bunch.h"

GEN_BUNCH_PROTOTYPES(uintbunch, uintalloc, unsigned int)

#define UINTBUNCH_ZERO GEN_BUNCH_ZERO

#endif

/* Public domain. */

#ifndef UINT16ALLOC_H
#define UINT16ALLOC_H

#include "uint16.h"
#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(uint16alloc, uint16, s, len, a)

#define UINT16ALLOC_ZERO GEN_ALLOC_ZERO

#endif

/* Public domain. */

/* MT-unsafe */

#include "skamisc.h"
#include "env.h"

char const *ucspi_get (char const *s)
{
  return ucspi_get_tmp(s, &satmp) ;
}

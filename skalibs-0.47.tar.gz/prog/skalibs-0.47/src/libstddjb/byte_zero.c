/* Public domain. */

#include "bytestr.h"

#ifdef USE_BASE_LIBC

#include <string.h>

void byte_zero (void *p, register unsigned int n)
{
  memset(p, 0, n) ;
}

#else

void byte_zero (void *p, register unsigned int n)
{
  register char *s = (char *)p ;
  while (n--) *s++ = 0 ;
}

#endif

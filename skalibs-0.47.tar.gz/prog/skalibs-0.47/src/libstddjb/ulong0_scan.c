/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU0(ulong, unsigned long, ULONG_MAX)

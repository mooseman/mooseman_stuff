/* Public domain. */

#undef USE_DJBALLOC
#include "gen_alloc.h"
#include "envalloc.h"

GEN_ALLOC_BASE_DEFS(envalloc, char const *, s, len, a, 4)

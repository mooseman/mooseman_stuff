/* Public domain. */

#include "stralloc.h"

GEN_ALLOC_reverse(stralloc, char, s, len, a)

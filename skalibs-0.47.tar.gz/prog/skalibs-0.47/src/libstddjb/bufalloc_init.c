/* Public domain. */

#include "stralloc.h"
#include "bufalloc.h"

void bufalloc_init (bufalloc_ref ba, int (*op)(int, char const *, unsigned int), int fd)
{
  stralloc_free(&ba->x) ;
  ba->op = op ;
  ba->fd = fd ;
  ba->p = 0 ;
}

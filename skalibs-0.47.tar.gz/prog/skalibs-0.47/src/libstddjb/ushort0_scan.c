/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU0(ushort, unsigned short, USHRT_MAX)

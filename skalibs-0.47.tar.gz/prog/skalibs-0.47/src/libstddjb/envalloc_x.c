/* Public domain. */

#undef USE_DJBALLOC
#include "gen_alloc.h"
#include "envalloc.h"

GEN_ALLOC_EXTENDED_DEFS(envalloc, char const *, s, len, a)

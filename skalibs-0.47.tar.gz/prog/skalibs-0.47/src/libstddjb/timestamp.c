/* Public domain. */

#include "tai.h"

void timestamp (char *s)
{
  struct taia now ;
  taia_now(&now) ;
  timestamp_fmt(s, &now) ;
}

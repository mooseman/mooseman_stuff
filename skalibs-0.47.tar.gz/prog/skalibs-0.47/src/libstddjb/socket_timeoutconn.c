/* Public domain. */

#include "uint16.h"
#include "tai.h"
#include "socket.h"

int socket_timeoutconn (int s, char const *ip, uint16 port, unsigned int timeout)
{
  struct taia deadline ;
  taia_now(&deadline) ;
  taia_addsec(&deadline, &deadline, timeout) ;
  return socket_deadlineconn(s, ip, port, &deadline) ;
}

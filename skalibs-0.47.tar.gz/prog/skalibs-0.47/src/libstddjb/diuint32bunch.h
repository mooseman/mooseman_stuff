/* Public domain. */

#ifndef DIUINT32BUNCH_H
#define DIUINT32BUNCH_H

#include "diuint32.h"
#include "diuint32alloc.h"
#include "gen_bunch.h"

GEN_BUNCH_PROTOTYPES(diuint32bunch, diuint32alloc, diuint32)

#endif

/* Public domain. */

#include "allreadwrite.h"
#include "buffer.h"

int buffer_flush (buffer_ref b)
{
  b->p += allreadwrite(b->op, b->fd, b->x + b->p, b->n - b->p) ;
  buffer_clean(b) ;
  return buffer_len(b) ? -1 : 0 ;
}

/* Public domain. */

#include <unistd.h>
#include "stralloc.h"
#include "djbunix.h"

void pathexec0_tmp (char const *const *argv, stralloc *tmp)
{
  if (!argv[0]) _exit(0) ;
  pathexec_tmp(argv, tmp) ;
}

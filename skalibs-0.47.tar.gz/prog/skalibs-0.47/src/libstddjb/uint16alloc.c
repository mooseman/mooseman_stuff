/* Public domain. */

#undef USE_DJBALLOC
#include "uint16.h"
#include "gen_alloc.h"
#include "uint16alloc.h"

GEN_ALLOC_BASE_DEFS(uint16alloc, uint16, s, len, a, 256)

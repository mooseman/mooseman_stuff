/* Public domain. */

/* MT-unsafe */

#include "buffer.h"

static char buf[BUFFER_OUTSIZE_SMALL] ;
static buffer b = BUFFER_INIT(&buffer_unixwrite, 1, buf, BUFFER_OUTSIZE_SMALL) ;
buffer_ref buffer_1small = &b ;

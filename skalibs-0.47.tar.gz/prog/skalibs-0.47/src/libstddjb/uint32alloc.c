/* Public domain. */

#undef USE_DJBALLOC
#include "uint32.h"
#include "gen_alloc.h"
#include "uint32alloc.h"

GEN_ALLOC_BASE_DEFS(uint32alloc, uint32, s, len, a, 256)

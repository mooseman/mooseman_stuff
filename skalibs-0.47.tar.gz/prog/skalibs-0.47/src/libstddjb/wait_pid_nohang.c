/* Public domain. */

#include "djbunix.h"

int wait_pid_nohang (int *wstat, int pid)
{
  int w = 0 ;
  int r = 0 ;
  while (r != pid)
  {
    r = wait_nohang(&w) ;
    if (r <= 0) return r ;
  }
  *wstat = w ;
  return pid ;
}

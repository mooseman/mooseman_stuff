/* Public domain. */

#include "fmtscan.h"

unsigned int long_fmt (char *fmt, long n)
{
  if (n >= 0) return ulong_fmt(fmt, n) ;
  *fmt++ = '-' ;
  return 1 + ulong_fmt(fmt, -n) ;
}

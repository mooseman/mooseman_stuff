/* Public domain. */

/* MT-unsafe */

#include "caltimedate.h"

int leapsecs_init ()
{
  static unsigned char flaginit = 0 ;
  if (flaginit) return 0 ;
  if (leapsecs_read() == -1) return -1 ;
  flaginit = 1 ;
  return 0 ;
}

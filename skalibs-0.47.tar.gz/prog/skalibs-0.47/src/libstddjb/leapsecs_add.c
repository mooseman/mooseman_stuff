/* Public domain */

/* MT-unsafe */

#include "tai.h"
#include "caltimedate.h"
#include "leapsecs_internal.h"

/* XXX: breaks tai encapsulation */

void leapsecs_add (struct tai *t, int hit)
{
  unsigned int i = 0 ;
  uint64 u = t->x ;
  if (leapsecs_init() == -1) return ;
  for (; i < leapsecs_num ; i++)
  {
    if (u < leapsecs[i].x) break ;
    if (!hit || (u > leapsecs[i].x)) ++u ;
  }
  t->x = u ;
}

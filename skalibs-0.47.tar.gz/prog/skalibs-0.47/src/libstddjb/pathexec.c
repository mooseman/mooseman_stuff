/* Public domain. */

/* MT-unsafe */

#include "env.h"
#include "djbunix.h"
#include "environ.h"

void pathexec (char const *const *argv)
{
  pathexec_fromenv(argv, environ, env_len(environ)) ;
}

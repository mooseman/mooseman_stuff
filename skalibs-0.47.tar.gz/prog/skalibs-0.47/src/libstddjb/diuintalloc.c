/* Public domain. */

#include "gen_alloc.h"
#include "diuint.h"
#include "diuintalloc.h"

GEN_ALLOC_BASE_DEFS(diuintalloc, diuint, s, len, a, 64)

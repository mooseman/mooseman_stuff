/* Public domain. */

#ifndef DIUINTALLOC_H
#define DIUINTALLOC_H

#include "gen_alloc.h"
#include "diuint.h"

GEN_ALLOC_PROTOTYPES(diuintalloc, diuint, s, len, a)

#define DIUINTALLOC_ZERO GEN_ALLOC_ZERO

#endif

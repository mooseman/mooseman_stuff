/* Public domain. */

#include "fmtscan.h"

unsigned int int_scan (char const *s, int *n)
{
  if ((*s == '-') || (*s == '+'))
  {
    unsigned int tmp ;
    register unsigned int r = uint_scan(s+1, &tmp) ;
    if (!r) return 0 ;
    *n = (*s == '-') ? -tmp : tmp ;
    return r + 1 ;
  }
  return uint_scan(s, (unsigned int *)n) ;
}

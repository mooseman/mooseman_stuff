/* Public domain. */

/* MT-unsafe */

#include "skamisc.h"
#include "djbunix.h"

void execvep (char const *file, char const *const *argv, char const *const *envp, char const *path)
{
  execvep_tmp(file, argv, envp, path, &satmp) ;
}

import whio
print('module =',whio)
fname = 'bogo.out';
f = whio.whio_dev_for_filename( fname, "w" )
print('f=',f)
sz = whio.whio_dev_write( f, "Hi, world!", 10 )
print('sz=',sz)
whio.whio_dev_finalize(f)
f = whio.whio_dev_for_filename( fname, "r" )
if f is None:
    raise Exception("Could not open "+fname+" for reading!")
frc = whio.whio_dev_fetch(f, 5);
if frc is None:
    raise Exception("Fetch failed!")
print('sizes:', frc.requested, frc.read, frc.alloced);
print('data:',frc.data);
print('alloced=',frc.alloced);
# Now clean up the object:
whio.whio_dev_fetch_free(frc);
print("Cleaned up and starting over...");
# Or there's a second approach:
frc = whio.whio_fetch_result();
print('alloced=',frc.alloced);
rc = whio.whio_dev_fetch_r( f, 30, frc );
print('rc=',rc)
print('sizes:', frc.requested, frc.read, frc.alloced);
print('data:',frc.data);
rc = whio.whio_dev_fetch_free_data(frc);
#print('fetch_free rc=',rc);
whio.whio_dev_finalize(f)

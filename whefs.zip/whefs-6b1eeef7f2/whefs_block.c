#include "whefs_details.c"
#include "whefs_encode.h"
#include <string.h> /* memset() */

const whefs_block whefs_block_init = whefs_block_init_m;
const whefs_block_list whefs_block_list_init = whefs_block_list_init_m;
bool whefs_block_id_is_valid( whefs_fs const * fs, whefs_id_type blid )
{
    return (
	    fs
	    && blid
	    && (blid <= fs->options.block_count)
	    )
	? true
	: false;
}

bool whefs_block_is_valid( whefs_fs const * fs, whefs_block const * bl )
{
    return bl ? whefs_block_id_is_valid( fs, bl->id ) : 0;
}

size_t whefs_block_id_pos( whefs_fs const * fs, size_t id )
{
    if( ! whefs_block_id_is_valid( fs, id ) )
    {
	return 0;
    }
    else
    {
	return fs->offsets[WHEFS_OFF_BLOCKS]
	    + ( (id-1) * fs->sizes[WHEFS_SZ_BLOCK] );
    }
}

size_t whefs_block_pos( whefs_fs const * fs, whefs_block const * bl )
{
    return bl ? whefs_block_id_pos( fs, bl->id ) : 0;
}


void whefs_block_update_used( whefs_fs * fs, whefs_block const * bl )
{
#if WHEFS_FS_BITSET_CACHE_ENABLED
    //if( ! whefs_block_id_is_valid( fs, bl ? bl->id : 0) ) return;
    if( bl->flags & WHEFS_FLAG_Used )
    {
	WHEFS_BCACHE_SET_USED(fs,bl->id);
    }
    else
    {
	WHEFS_BCACHE_UNSET_USED(fs,bl->id);
	if( fs->hints.unused_block_start > bl->id )
	{
	    fs->hints.unused_block_start = bl->id;
	}
    }
#endif /* WHEFS_FS_BITSET_CACHE_ENABLED */
}

/**
   The on-disk size of the header bytes at the start of
   each block.
*/
static size_t whefs_fs_block_header_len =
    1 /* tag byte */
    + whefs_sizeof_encoded_id_type /* block.id */
    + whio_dev_sizeof_uint32 /* block.flags */
    + whefs_sizeof_encoded_id_type /* block.next_block */
    ;
size_t whefs_fs_sizeof_block( whefs_fs_options const * opt )
{
    return opt
	? (opt->block_size + whefs_fs_block_header_len)
	: 0;
}


size_t whefs_block_id_data_pos( whefs_fs const * fs, size_t id )
{
    size_t rc = whefs_block_id_pos( fs, id );
    if( rc )
    {
	rc += whefs_fs_block_header_len;
    }
    return rc;
}

size_t whefs_block_data_pos( whefs_fs const * fs, whefs_block const * bl )
{
    return bl ? whefs_block_id_data_pos( fs, bl->id ) : 0;
}

int whefs_block_id_seek( whefs_fs const * fs, whefs_id_type id )
{
    size_t p = whefs_block_id_pos( fs, id );
    if( ! p ) return whefs_rc.ArgError;
    size_t sk = fs->dev->api->seek( fs->dev, p, SEEK_SET );
    return (p == sk) ? whefs_rc.OK : whefs_rc.IOError;
}

int whefs_block_seek( whefs_fs const * fs, whefs_block const * bl )
{
    return bl ? whefs_block_id_seek( fs, bl->id ) : 0;
}

int whefs_block_id_seek_data( whefs_fs const * fs, whefs_id_type id, size_t * tgt )
{
    size_t p = whefs_block_id_data_pos( fs, id );
    if( ! p ) return whefs_rc.ArgError;
    size_t sk = fs->dev->api->seek( fs->dev, p, SEEK_SET );
    return (p == sk) ? ((tgt?(*tgt=sk):0),whefs_rc.OK) : whefs_rc.IOError;
}

int whefs_block_seek_data( whefs_fs const * fs, whefs_block const * bl, size_t * tgt )
{
    return bl ? whefs_block_id_seek_data( fs, bl->id, tgt ) : 0;
}


/**
   On-disk blocks are prefixed with this character.
*/
static const unsigned char whefs_block_tag_char = 0xdf /* sharp S, becase it looks like a B */;

int whefs_block_flush( whefs_fs * fs, whefs_block const * bl )
{
    if( ! whefs_block_id_is_valid(fs,bl ? bl->id : 0) ) return whefs_rc.ArgError;
    int rc = whefs_rc.OK;
    size_t pos = bl->id ? whefs_block_pos(fs,bl) : fs->dev->api->tell( fs->dev );
    //WHEFS_DBG( "Writing block #%u", bl->id );
    if( bl->id )
    {
	pos = fs->dev->api->seek( fs->dev, pos, SEEK_SET );
	rc = (whefs_rc.SizeTError == pos) ? whefs_rc.RangeError : whefs_rc.OK;
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("FAILED setting correct write position for inode %u at offset %u with error code %d!", bl->id, pos, rc );
	    return rc;
	}
    }

#if 1
    fs->dev->api->write( fs->dev, &whefs_block_tag_char, 1 );
    size_t check = 0;
    //check = whio_dev_uint32_encode( fs->dev, EXP );
    //if( whio_dev_sizeof_uint32 != check ) return whefs_rc.IOError
    check = whefs_dev_id_encode( fs->dev, bl->id );
    check = whio_dev_uint32_encode( fs->dev, bl->flags );
    check = whefs_dev_id_encode( fs->dev, bl->next_block );
#else
    #error "we can't do this until/unless the block metadata and data data are separated."
    enum {
    bufSize = 1 /* tag char */
    + whefs_sizeof_encoded_id_type /* bl->id */
    + whefs_sizeof_encoded_uint32 /* bl->flags */
    + whefs_sizeof_encoded_id_type /* bl->next_block */
    };
    unsigned char buf[bufSize];
    // TODO: use whefs_encode_xxx() here
    buf[0] = whefs_block_tag_char;
    size_t off = 1;
    whefs_id_encode( buf + off, bl->id );
    off += whefs_sizeof_encoded_id_type;
    whefs_uint32_encode( buf + off, bl->flags );
    off += whefs_sizeof_encoded_uint32;
    whefs_id_encode( buf + off, bl->next_block );
    rc = whio_blockdev_write( &fs->fences.b, bl->id - 1, buf );
    WHEFS_DBG("blockdev write for id#"WHEFS_ID_TYPE_PFMT"=%d",bl->id-1,buf);
#endif
    whefs_block_update_used( fs, bl );
    //WHEFS_DBG("block_write for block #%u returning %d", bl->id, rc );
    return rc;
}

int whefs_block_read( whefs_fs * fs, whefs_block * bl )
{
    if( ! whefs_block_id_is_valid(fs,bl ? bl->id : 0)  )
    {
	if( bl )
	{
	    *bl = whefs_block_init;
	    return whefs_rc.OK;
	}
	return whefs_rc.ArgError;
    }
    const short doSet = 1;
    if( doSet )
    {
	size_t to = bl->id ? whefs_block_pos( fs, bl ) : whefs_rc.SizeTError;
	if( (whefs_rc.SizeTError == to)
	    ||
	    (whefs_rc.SizeTError == fs->dev->api->seek( fs->dev, to, SEEK_SET ))
	    )
	{
	    return whefs_rc.RangeError;
	}
    }
    // FIXME: error handling!
    unsigned char check = 0;
    fs->dev->api->read( fs->dev, &check, 1 );
    if( whefs_block_tag_char != check )
    {
	WHEFS_DBG_ERR("Cursor is not positioned at a data block!");
	return whefs_rc.InternalError;
    }
    whefs_dev_id_decode( fs->dev, &bl->id );
    whio_dev_uint32_decode( fs->dev, &bl->flags );
    whefs_dev_id_decode( fs->dev, &bl->next_block );
    whefs_block_update_used( fs, bl );
    //WHEFS_DBG("Read block #%"WHEFS_ID_TYPE_PFMT". flags=0x%x",bl->id,bl->flags);
    return whefs_rc.OK;
}

int whefs_block_wipe_data( whefs_fs * fs, whefs_block const * bl, size_t startPos )
{
    size_t fpos = 0;
    int rc = whefs_block_id_seek_data( fs, bl->id, &fpos );
    if( whefs_rc.OK != rc ) return rc;
    const size_t bs = whefs_fs_options_get(fs)->block_size;
    if( startPos >= bs ) return whefs_rc.RangeError;
    if( (fpos + bs) < fpos /* overflow! */ ) return whefs_rc.RangeError;
    const size_t count = bs - startPos;
    {
	enum { bufSize = 1024 * 2 };
	static unsigned char buf[bufSize] = {'*',0};
	if( '*' == buf[0] )
	{
	    memset( buf+1, 0, bufSize-1 );
	    buf[0] = 0;
	}
	size_t wrc = 0;
	size_t total = 0;
	while( total < count )
	{
	    const size_t x = count - total;
	    wrc = whefs_fs_write( fs, buf, (bufSize > x) ? x : bufSize);
	    if( ! wrc ) break;
            // ^^^ fixme: return an error if wrc!=requested write size
	    total += wrc;
	}
	//WHEFS_DBG("Wrote %u bytes to zero block #%u. Range=[%u .. %u)", total, bl->id, fpos, fpos+count );
    }
    return whefs_rc.OK;
}

int whefs_block_wipe( whefs_fs * fs, whefs_block * bl,
		      bool wipeData,
		      bool wipeMeta,
		      bool deep )
{
    if( ! whefs_block_id_is_valid( fs, bl ? bl->id : 0 ) ) return whefs_rc.ArgError;
    size_t fpos = 0;
    const size_t bs = whefs_fs_options_get(fs)->block_size;
    if( (fpos + bs) < fpos /* overflow! */ ) return whefs_rc.RangeError;
    int rc = 0;
    if( deep && bl->next_block )
    {
	whefs_block next = *bl;
	whefs_block xb = *bl;
	bl->next_block = 0;
	while( xb.next_block )
	{
	    if( whefs_rc.OK != (rc = whefs_block_read_next( fs, &xb, &next )) )
	    {
		WHEFS_DBG_ERR("block #%u: could not load next block, #%u", xb.id, xb.next_block );
		return rc;
	    }
	    xb = next;
	    next.next_block = 0; /* avoid that the next call recurses deeply while still honoring 'deep'. */
	    if( whefs_rc.OK != (rc = whefs_block_wipe( fs, &next, wipeData, wipeMeta, deep )) )
	    {
		WHEFS_DBG_ERR("Error zeroing block #%u! deep=%s", xb.id, xb.next_block, deep ? "true" : "false" );
		return rc;
	    }
	}
    }
    if( wipeMeta )
    {
	if( ! deep && bl->next_block )
	{
	    WHEFS_FIXME("Warning: we're cleaning up the metadata without cleaning up children! We're losing blocks!");
	}
	const whefs_id_type oid = bl->id;
	//WHEFS_DBG("Wiping block #%"WHEFS_ID_TYPE_PFMT". flags=0x%x",bl->id,bl->flags);
	*bl = whefs_block_init;
	bl->id = oid;
	whefs_block_flush( fs, bl );
	//WHEFS_DBG("Wiped block #%"WHEFS_ID_TYPE_PFMT". flags=0x%x",bl->id,bl->flags);
	if( oid < fs->hints.unused_block_start )
	{
	    fs->hints.unused_block_start = oid;
	}
    }
    if( wipeData )
    {
	rc = whefs_block_wipe_data( fs, bl, 0 );
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("Wiping block #%u failed with error code #%d!\n", bl->id, rc);
	    return rc;
	}
    }
    return whefs_rc.OK;
}

int whefs_block_read_next( whefs_fs * fs, whefs_block const * bl, whefs_block * nextBlock )
{
    if( !nextBlock || !whefs_block_id_is_valid(fs,bl?bl->id:0) ) return whefs_rc.ArgError;
    size_t nb = bl->next_block;
    /** don't reference bl after this, for the case that (bl == nextBlock) */
    if( ! nb ) return whefs_rc.RangeError;
    *nextBlock = whefs_block_init;
    nextBlock->id = nb;
    return whefs_block_read( fs, nextBlock );
}


int whefs_block_next_free( whefs_fs * fs, whefs_block * tgt, bool markUsed )
{
    if( ! fs || !tgt ) return whefs_rc.ArgError;
    whefs_id_type i = fs->hints.unused_block_start;
    if( ! i )
    {
	i = fs->hints.unused_block_start = 1;
    }
    whefs_block bl = whefs_block_init;
    for( ; i <= fs->options.block_count; ++i )
    {
#if WHEFS_FS_BITSET_CACHE_ENABLED
	if( WHEFS_BCACHE_IS_USED(fs,i) )
	{
	    //WHEFS_DBG("Got cached block USED entry for block #%u", i );
	    continue;
	}
	//WHEFS_DBG("Cache says block #%i is unused. markUsed=%d", i, markUsed );
#endif
        // FIXME: try an flock here and skip to the next if we can't get a lock.
        // Use a write lock if markUsed is true???
	bl.id = i;
	int rc = whefs_block_read( fs, &bl );
	//WHEFS_DBG("Checking block #%u for freeness. Read rc=%d",i,rc);
	if( whefs_rc.OK != rc )
	{
	    return rc;
	}
	if( bl.id != i )
	{
	    assert( 0 && "block id mismatch after successful whefs_block_read()" );
	    WHEFS_FIXME("Block id mismatch after successful whefs_block_read(). Expected %u but got %u.", i, bl.id );
	    return whefs_rc.InternalError;
	}
	if( WHEFS_FLAG_Used & bl.flags )
	{
	    whefs_block_update_used( fs, &bl );
	    continue;
	}
	if( markUsed )
	{
	    bl.flags |= WHEFS_FLAG_Used;
	    whefs_block_flush( fs, &bl );
	    fs->hints.unused_block_start = bl.id + 1;
	    // FIXME: error handling!
	}
	*tgt = bl;
	//WHEFS_DBG( "Returning next free block: #%u",tgt->id );
	return whefs_rc.OK;
    }
    WHEFS_DBG_ERR("VFS appears to be full :(");
    return whefs_rc.FSFull;
}

int whefs_block_append( whefs_fs * fs, whefs_block * bl, whefs_block * tgt )
{
    if( ! fs || !tgt ) return whefs_rc.ArgError;
    if( bl && bl->next_block ) return whefs_rc.ArgError;
    int rc = 0;
    const size_t oid = bl ? bl->id : 0;
    if( ! oid )
    {
	return whefs_block_next_free( fs, tgt, true );
    }
    whefs_block tail = *bl;// = whefs_block_init;
    while( tail.next_block )
    {
	rc = whefs_block_read_next( fs, &tail, &tail );
	if( whefs_rc.OK != rc ) return rc;
    }
    rc = whefs_block_next_free( fs, tgt, true );
    if( whefs_rc.OK != rc ) return rc;
    tail.next_block = tgt->id;
    whefs_block_flush( fs, &tail );
    whefs_block_flush( fs, tgt );
    return whefs_rc.OK;
}


#ifndef WANDERINGHORSE_NET_WHIO_H_INCLUDED
#define WANDERINGHORSE_NET_WHIO_H_INCLUDED

#include "whio_devs.h"
#include "whio_streams.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* WANDERINGHORSE_NET_WHIO_H_INCLUDED */

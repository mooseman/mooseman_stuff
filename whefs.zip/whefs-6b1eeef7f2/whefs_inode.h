#if !defined(WANDERINGHORSE_NET_WHEFS_INODE_H_INCLUDED)
#define WANDERINGHORSE_NET_WHEFS_INODE_H_INCLUDED 1
/*
  Author: Stephan Beal (http://wanderinghorse.net/home/stephan/

  License: Public Domain
*/

/**
   This file contains the whefs_inode parts of the whefs
   private/internal API.
*/
#include "whefs.h"

#ifdef __cplusplus
extern "C" {
#endif


/** @struct whefs_block

whefs_block holds the metadata for the data blocks of a VFS, but do
not actually hold the data.
*/
struct whefs_block
{
    /**
       Sequential id number. Value of 0 is reserved for "invalid block".
    */
    whefs_id_type id;
    /**
       Internal flags.
    */
    uint32_t flags;
    /* id of next block */
    whefs_id_type next_block;
};
typedef struct whefs_block whefs_block;

/** @def whefs_block_init_m

    Empty static initializer for whefs_block objects.
 */
#define whefs_block_init_m  \
    { \
    0, /* id */ \
    0, /* flags */ \
    0 /* next_block */ \
    }

/** Empty initialization object for whefs_block objects. */
extern const whefs_block whefs_block_init;

/** @def WHEFS_INODE_RELATIVES

This is going away - don't use it.

WHEFS_INODE_RELATIVES determines whether the underlying support for
directories/subdirectories is turned on. This changes the filesystem
layout and the in-memory size of inode entries.

*/
#define WHEFS_INODE_RELATIVES 0


typedef struct whefs_block_list
{
    whefs_block * list;
    whefs_id_type alloced;
    whefs_id_type count;
} whefs_block_list;

/**
   Convenience macro for places where a whefs_block_list
   object must be statically initialized.
*/
#define whefs_block_list_init_m {0,0,0}
/**
   Empty initialization object.
*/
extern const whefs_block_list whefs_block_list_init;

/** @struct whefs_inode

For most intents and purposes, a whefs_inode object can be considered
to be a file entry in a VFS.
*/
typedef struct whefs_inode
{
    /**
       Sequential id number. Value of 0 is reserved for "invalid
       inode" and ID 1 is reserved for the root node entry of a VFS.
    */
    whefs_id_type id;

    /**
       Flags from the whefs_flags enum. Persistant.
    */
    uint32_t flags;

    /**
       ID of first block. Persistant.
    */
    whefs_id_type first_block;

    /**
       EOF position (i.e. size of the associated data)
    */
    uint32_t data_size;

    /**
       Timestamp of last write/change to the inode. This type may
       change at some point (to uint64_t). Persistant.
     */
    uint32_t mtime;

    /** Used by the open filehandle tracker. Transient. */
    uint16_t open_count;
    /** Is used to mark write ownership of an inode. Transient. */
    void const * writer;
    /**
       This is used by whefs_block_for_pos() (the heart of the i/o
       routines) to keep the block list for an opened inode in
       memory. This saves boatloads of i/o for common use cases.
       Transient.
    */
    whefs_block_list blocks;
    /** Transient string used only by opened nodes. */
    whefs_string name;
} whefs_inode;

#define whefs_inode_init_m { \
	0, /* id */ \
	WHEFS_FLAG_Unused, /* flags */ \
        0, /* first_block */ \
        0, /* data_size */ \
        0, /* mtime */ \
        0, /* open_count */ \
        0, /* writer */ \
	whefs_block_list_init_m /*blocks */, \
        whefs_string_init_m /* name */ \
    }


//static const whefs_inode whefs_inode_init = whefs_inode_init_m;
/** Empty initialization object. */
extern const whefs_inode whefs_inode_init;

typedef struct whefs_inode_list
{
    whefs_inode inode;
    struct whefs_inode_list * next;
    struct whefs_inode_list * prev;
} whefs_inode_list;
#define whefs_inode_list_init_m { whefs_inode_init_m, 0, 0 }
extern const whefs_inode_list whefs_inode_list_init;
typedef struct whefs_inode_cache
{
    whefs_inode ** list;
    whefs_id_type size;
    whefs_id_type alloced;
} whefs_inode_cache;

#define whefs_inode_cache_init_m { 0, 0, 0 }



/**
   Reads a whefs_inode's metadata from disk. Neither n nor n->id may
   be 0, but the remaining contents of n are irrelevant (they will be
   overwritten). On success, whefs_rc.OK is returned and n is updated
   to the on-disk state, otherwise some other value is returned and n
   is left in an undefined state (that is, possibly partially
   populated).

   Ownership of n is not changed by calling this function.

   Typical usage:

   @code
   whefs_inode ino = whefs_inode_init;
   ino.id = 42;
   whefs_inode_read( fs, &ino );
   @endcode
*/
int whefs_inode_read( whefs_fs * fs, whefs_inode * n );

/**
   Reads the flags field of the given inode and assigns the flags
   argument to their value. fs may not be null and nid must be a valid
   inode id for fs or the routine will fail. flags may be 0, in which
   case this is simply a very elaborate way to tell if an inode is
   valid.

   On success flags is modified (if it is not null) and whefs_rc.OK is
   returned. On failure flags is not modified and non-OK is returned.
   
   This routine returns the fs i/o device to its original position
   when it is done, so calling this behaves "as if" the cursor has not
   moved. The one exception is if the seek to the correct inode fails,
   in which case the cursor position is in an undefined state and
   error recovery must begin (writing at that point may corrupt the
   vfs).

   If the given inode ID is currently opened, the flags are taken
   from the opened copy and no i/o is necessary.
*/
int whefs_inode_read_flags( whefs_fs * fs, whefs_id_type nid, uint32_t * flags );

/**
   Opens an inode for concurrent (but NOT multi-threaded!) access,
   such that the node will be shared by open file and devive handles.

   This should be the only function the remaining API uses to "open
   up" an inode.

   On success whefs_rc.OK is returned tgt is set to a pointer to the
   shared inode. The pointer is owned by fs but must be closed by
   calling whefs_inode_close().

   On error tgt is not modified and some other value is
   returned. Errors can be:
   
   - nodeID is not a valid node.
   - could not allocate space for shared inode.
   - !fs or !tgt

   If the inode is to be opened read-only, pass 0 for the writer argument.
   If the inode is to be opened with write mode enabled, writer must be
   an opaque value which uniquely identifies the writer (e.g. the owning
   object). An attempt to open an inode for a second or subsequent writer
   will fail with whefs_rc.AccessError.

   @see whefs_inode_close()
*/
int whefs_inode_open( whefs_fs * fs, whefs_id_type nodeID, whefs_inode ** tgt, void const * writer );

/**
   The converse of whefs_inode_open(), this unregisters a reference to
   the given inode. src and writer MUST be the same pointers as
   returned from resp. passed to whefs_inode_open() (NOT addresses to
   copied objects) or this operation will fail and client code may end
   up leaking one opened inode handle.

   On success, whefs_rc.OK is returned. The src object was allocated
   by whefs_inode_open() and will be cleaned up here.

   If (writer != 0) and (writer == src->writer) then the inode is
   flushed to disk as part of the closing process.

   @see whefs_inode_open()
*/
int whefs_inode_close( whefs_fs * fs, whefs_inode * src, void const * writer );


/**
   Writes n to disk. If any arguments are 0 then whefs_rc.ArgError
   is returned. If n->id is 0 or more than fs->options.inode_count then
   whefs_rc.RangeError is returned.

   On success, whefs_rc.OK is returned.

   Note that this does not flush the inode's name, as that is handled
   separately. See whefs_inode_name_set().
*/
int whefs_inode_flush( whefs_fs * fs, whefs_inode const * n );

/**
   Searches for the next free inode and assigns tgt to that value. If markUsed
   is true then the inode is also marked as used, otherwise a susequent call
   to this function might return the same inode.

   On success it updates tgt and returns whefs_rc.OK. On error it
   returns some other value and does not update tgt.
*/
int whefs_inode_next_free( whefs_fs * fs, whefs_inode * tgt, bool markUsed );

/**
   Searches fs for an inode with the given name. On success, tgt is updated to
   that inode's state and whefs_rc.OK is returned, otherwise some other value
   is returned.

   Bugs:

   - Directory structures are not yet supported.
*/
int whefs_inode_by_name( whefs_fs * fs, char const * name, whefs_inode * tgt );


/**
   Returns true if n is "valid" - has a non-zero id in a range legal
   for the given fs object.
*/
bool whefs_inode_is_valid( whefs_fs const * fs, whefs_inode const * n );

/**
   Equivalent to whefs_inode_is_valid(), but takes an inode ID instead
   of an inode object.
*/
bool whefs_inode_id_is_valid( whefs_fs const * fs, whefs_id_type nid );

/**
   Creates a new i/o device associated with the given inode (which
   must be a valid inode). The device allows reading and writing
   from/to the inode as if it were a normal i/o device, using
   fs's data blocks as the underlying data store. The capability
   allows such a device to itself be the host of a whefs_fs filesystem
   That is, it makes it possible to embed one VFS with another, to
   an arbitrary depth.

   On success a new device is returned, which eventualy must be
   destroyed via dev->finalize(dev). On error, 0 is returned.

   The given inode must be a fully populated object. The returned
   device will take over doing updates of that object's on-disk
   data. That is, changes to the inode made via the device
   cannot be tracked via the passed-in inode pointer.

   The returned object conforms as closely as possible to the
   whio_dev API specifications, but there may still be an
   outstanding corner case or three.

   whio_dev::ioctl(): the returned object supports the
   whio_dev_ioctl_GENERAL_size ictl to return the current size of the
   device.
*/
whio_dev * whefs_dev_for_inode( whefs_fs * fs, whefs_id_type nodeID, bool writeMode );

#if 0 // no longer needed
/**
   Returns the on-disk size of an inode INCLUDING opt->filename_length.
   Semantics of the library will soon (as of 20090115) change to remove
   the string length from the inode itself.
*/
size_t whefs_fs_sizeof_inode( whefs_fs_options const * opt );
#endif

/**
   Returns the on-disk position of the given inode, which must be a
   valid inode id for fs. fs must be opened and initialized. On error
   (!fs or !nid, or nid is out of range), 0 is returned. Does not require
   any i/o.
*/
size_t whefs_inode_pos( whefs_fs const * fs, whefs_id_type nid );

/**
   Seeks to the given inode's on-disk position. Returns whefs_rc.OK
   on success.
*/
int whefs_inode_seek( whefs_fs * fs, whefs_inode const * ino );

/**
   Equivalent to whefs_inode_seek(), but takes an inode ID.
*/
int whefs_inode_id_seek( whefs_fs * fs, whefs_id_type id );

/**
   Sets n's name to name. Returns whefs_rc.OK on success, or some
   other value on error. If the name is longer than the smaller of
   whefs_fs_options_get(fs)->filename_length or
   WHEFS_MAX_FILENAME_LENGTH, whefs_rc.RangeError is returned and n is
   not modified.

   This function does NOT change n->mtime but does update the on-disk
   record. If n is currently opened (that is, n->open_count is not 0)
   then its in-memory record (whefs_inode::name) is also updated, otherwise
   n->name is NOT updated (because it would probably not get cleaned
   up).
*/
int whefs_inode_name_set( whefs_fs * fs, whefs_inode * n, char const * name );

/**
   Loads the name for the given inode id into the given target string
   (which may not be null). If tgt has memory allocated to it, it may
   be re-used (or realloc()'d) by this function, so the caller must
   copy it beforehand if it will be needed later. If the read-in
   string has a length of 0 and tgt->alloced is not 0 (i.e. tgt
   already has content), then the string's memory is kept but is
   zeroed out and tgt->length will be set to 0.

   Returns whefs_rc.OK on success.
*/
int whefs_inode_name_get( whefs_fs * fs, whefs_id_type id, whefs_string * tgt );


/**
   If !n then it returns whefs_rc.ArgError, otherwise it returns
   whefs_rc.OK and updates n->mtime to the current time. It does not
   write the changes to disk.
*/
int whefs_inode_update_mtime( whefs_fs * fs, whefs_inode * n );

/**
   Marks the given inode as unused and wipes all associated data
   blocks. The inode need not be fully populated - only its
   ID is considered.

   The the inode is currently opened, unlinking will not be allowed
   and whefs_rc.AccessError will be returned.

   Returns whefs_rc.OK on success. On error, we cannot say how much of
   the unlink worked before we aborted (e.g. not all blocks might have
   been cleared).

   Ownership of inode is not transfered but the inode object will be
   wiped clean of all state except its ID.
  
*/
int whefs_inode_unlink( whefs_fs * fs, whefs_inode * inode );

/**
   Equivalent to whefs_inode_unlink(), but takes an inode ID.
*/
int whefs_inode_id_unlink( whefs_fs * fs, whefs_id_type nid );


/**
   Searches the table of opened inodes for the given ID. If an entry
   is found, tgt is assigned to a pointer to that object and
   whefs_rc.OK is returned. If none is found, or some other error
   happens (e.g. fs or nodeID are invalid) then some other value is
   returned and tgt is not modified.

   WARNING:

   This routine allows the caller to bypass the single-writer
   restriction on inodes, and should be used with care. It is in the
   semi-public API only to support whefs_file_rename().

*/
int whefs_inode_search_opened( whefs_fs * fs, whefs_id_type nodeID, whefs_inode ** tgt );

/**
   Encodes src (which may not be null) to dest, which must be valid memory
   of at least whefs_sizeof_encoded_inode bytes long. On succes whefs_rc.OK
   is returned and whefs_sizeof_encoded_inode bytes of dest are written.
   The only error conditions are that neither src nor dest are null, so if
   you are certain you're passing non-nulls then you can ignore the error
   check.
*/
int whefs_inode_encode( unsigned char * dest, whefs_inode const * src );

/**
   Encodes dest (which may not be null) from src, which must be valid memory
   at least whefs_sizeof_encoded_inode bytes long and containing an encoded
   inode (see whefs_inode_encode()). On succes whefs_rc.OK
   is returned and whefs_sizeof_encoded_inode bytes are read from src dest.

   Unlike whefs_inode_encode(), this routine has many potential points
   of failure (as there are several values to be decoded), so checking
   the return value is a must. On success, whefs_rc.OK is returned.
   If src or dest are null then whefs_rc.ArgError is returned. If
   decoding fails then whefs_rc.ConsistencyError is returned.
*/
int whefs_inode_decode( unsigned char const * src, whefs_inode * dest );

#ifdef __cplusplus
} /* extern "C" */
#endif


#endif /* WANDERINGHORSE_NET_WHEFS_INODE_H_INCLUDED */

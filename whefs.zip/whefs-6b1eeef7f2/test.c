/*
  Test/demo app for libwhefs.

  Author: Stephan Beal (http://wanderinghorse.net/home/stephan/)

  License: Public Domain
*/
#ifdef NDEBUG
#  undef NDEBUG
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <unistd.h> /* sleep() */
#include "whefs.h"

#if 1
#define MARKER if(1) printf("MARKER: %s:%d:%s():\n",__FILE__,__LINE__,__func__); if(1) printf
#else
static void bogo_printf(char const * fmt, ...) {}
#define MARKER if(0) bogo_printf
#endif


struct app_data {
    whefs_fs_options fsopts;
} ThisApp;

int test_one()
{
    MARKER("starting test\n");
    char const * fname = "bogo.whefs";
#if 0
    char const * fmode = "r+";
    FILE * ff = fopen(fname,fmode);
    MARKER("fopen(%s,%s) = %p\n",fname,fmode,(void const *)ff);
    if( ff ) fclose(ff);
#endif
    whefs_fs * fs = 0;
    int rc = whefs_mkfs( fname, &ThisApp.fsopts, &fs );
    MARKER("mkfs() rc = %d\n", rc);
    assert((rc == whefs_rc.OK) && "mkfs failed :(" );
    MARKER("mkfs() worked.\n");

    int irc = whefs_rc.OK;
    //irc = whefs_test_insert_dummy_files( fs );
    assert( (whefs_rc.OK == irc) && "insertion of dummy data failed!" );

    whefs_fs_dump_info( fs, stdout );
    whefs_fs_finalize( fs );
    fs = 0;

#if 1
    MARKER("Closed FS. Re-opening it...\n");
    if( whefs_rc.OK != whefs_openfs( fname, &fs, 0 ) )
    {
	MARKER("openfs(%s) failed!\n",fname);
	return 1;
    }
    whefs_fs_dump_info( fs, stdout );
    whefs_fs_finalize( fs );
#endif

    MARKER("ending test\n");
    return 0;
}

int test_ramfs()
{
    MARKER("starting ramvfs test\n");
    char const * fname = ":memory:";
    whefs_fs * fs = 0;
    size_t rc = whefs_mkfs( fname, &ThisApp.fsopts, &fs );
    assert((rc == whefs_rc.OK) && "mkfs failed :(" );
    MARKER("mkfs() worked.\n");
    whefs_fs_dump_info( fs, stdout );

    int irc = whefs_test_insert_dummy_files( fs );
    assert( (whefs_rc.OK == irc) && "insertion of dummy data failed!" );

    fname = "fopen_test.file";
    whefs_file * F = whefs_fopen( fs, fname, "r+" );
    MARKER("F (read-write) == 0x%p\n", (void const *)F );
    assert(F && "whefs_fopen() failed");
    whio_dev * FD = whefs_fdev( F );
    size_t i = 0;
    for( ; i < 15; ++i )
    {
	whefs_fwritef(F, "Entry #%u ", i);
	//whio_dev_writef( FD, "Entry #%u ", i);
    }
    whio_dev_rewind( FD );

    enum { bufSize = 256 };
    char buf[bufSize];
    memset( buf, 0, bufSize );
    FD->api->seek( FD, 125, SEEK_SET );
    rc = FD->api->read( FD, buf, 40 );
    MARKER("FD read rc=%u\n", rc );
    if( rc )
    {
	MARKER("Read bytes: [%s]\n", buf );
    }

    whefs_fclose( F );
#if 1
    F = whefs_fopen( fs, fname, "r" );
    MARKER("F (read-only) == 0x%p\n", (void const *)F );
    assert(F && "whefs_fopen() failed");
    whefs_fclose( F );
#endif
    fname = "memory.whefs";
    int drc = whefs_fs_dump_to_filename( fs, fname );
    if( whefs_rc.OK != drc )
    {
	MARKER("dump failed with rc %d\n", drc );
	assert( 0 && "fs dump failed" );
    }
    MARKER("Dumped in-memory vfs to [%s]\n",fname);

    whefs_id_type lscount = 0;
    char const * lspat = "*f*";
    whefs_string * ls = whefs_ls( fs, lspat, &lscount );
    whefs_string * head = ls;
    MARKER("VFS File list matching '%s':\n",lspat);
    while( ls )
    {
	printf("\t%s\n", ls->string );
	ls = ls->next;
    }
    whefs_string_finalize( head, true );

    whefs_fs_finalize( fs );
    MARKER("ending test\n");
    return 0;
}

int test_multiple_files()
{
    MARKER("starting inode opener tests\n");
    char const * fname = "multiples.whefs";
    whefs_fs * fs = 0;
    int rc = whefs_mkfs( fname, &ThisApp.fsopts, &fs );
    assert((rc == whefs_rc.OK) && "mkfs failed :(" );
    MARKER("Created vfs file [%s]\n",fname);


    fname = "one.bogo";
    whefs_file * F = 0;

#if 1
    F = whefs_fopen( fs, fname, "r+" );
    MARKER("F (read-write) == 0x%p\n", (void const *)F );
    assert(F && "whefs_fopen() failed");
#endif
    fname = "one-renamed.bogo";
    rc = whefs_file_set_name( F, fname );
    assert( (whefs_rc.OK == rc) && "file rename failed!");

#if 1
    whefs_file * F2 = 0;
    {
	F2 = whefs_fopen( fs, fname, "r+" );
	assert( !F2 && "F2 is correctly null!");
	MARKER("Second attempt to open read/write correctly failed.\n");
    }

    MARKER("Starting writes...\n");
    whio_dev * FD = 0;
    {
	FD = whefs_fdev( F );
	size_t i = 0;
	for( ; i < 15; ++i )
	{
	    whefs_fwritef(F, "Entry #%u ", i);
	    //whio_dev_writef( FD, "Entry #%u ", i);
	}
	whio_dev_rewind( FD );
    }
    MARKER("Writes done.\n");
    //FD->api->flush(FD);
#endif

#if 1
    MARKER("Attempting to open concurrently but read-only...\n");
    F2 = whefs_fopen( fs, fname, "r" );
    assert( F2 && "fopen for read-only mode failed!");
    whio_dev * FD2 = whefs_fdev( F2 );
    enum { bufSize = 256 };
    char buf[bufSize];
    memset( buf, 0, bufSize );
    const size_t dPos = 125;
    MARKER("FD->size=%"WHIO_SIZE_T_PFMT", FD2->size=%"WHIO_SIZE_T_PFMT"\n",
	   whio_dev_size( FD ),
	   whio_dev_size( FD2 ) );
    FD->api->seek( FD, dPos + 2, SEEK_SET );
    FD->api->write( FD, "X X X", 5 );
    FD2->api->seek( FD2, dPos, SEEK_SET );
    rc = FD2->api->read( FD2, buf, 40 );
    MARKER("FD2 read rc=%u\n", rc );
    if( rc )
    {
	MARKER("Read bytes: [%s]\n", buf );
    }
    whefs_fclose( F2 );
#endif

    whefs_fclose( F );
    whefs_fs_finalize( fs );
    MARKER("ending test\n");
    return 0;
}

int test_truncate()
{
    MARKER("starting truncate tests\n");
    char const * fname = "truncate.whefs";
    whefs_fs * fs = 0;
    int rc = whefs_mkfs( fname, &ThisApp.fsopts, &fs );
    assert((rc == whefs_rc.OK) && "mkfs failed :(" );
    MARKER("Created vfs file [%s]\n",fname);

    fname = "one.bogo";
    whefs_file * F = 0;

    F = whefs_fopen( fs, fname, "r+" );
    MARKER("F (read-write) == 0x%p\n", (void const *)F );
    assert(F && "whefs_fopen() failed");
    whio_dev * FD = 0;
    {
	FD = whefs_fdev( F );
	size_t i = 0;
	for( ; i < 15; ++i )
	{
	    //whefs_fwritef(F, "Entry #%u ", i);
	    whio_dev_writef( FD, "Entry #%u ", i);
	}
	whio_dev_rewind( FD );
    }
    size_t truncSize = 100;
    whefs_ftrunc( F, truncSize );
    assert( whio_dev_size( FD ) == truncSize );
    const size_t step = 10;
    whefs_fseek( F, truncSize + step, SEEK_SET );
    FD->api->write( FD, "hi", 2 );
    assert( whio_dev_size( FD ) == (2 + step + truncSize) );
    whefs_fclose( F );
    FD = 0;

    fname = "file2";
    F = whefs_fopen( fs, fname, "r+" );
    assert( F );
    whefs_file_write( F, "hi hi", 5 );
    truncSize = 6000;
    rc = whefs_ftrunc( F, truncSize );
    assert( whefs_fsize( F ) == truncSize );
    truncSize = 2050;
    rc = whefs_ftrunc( F, truncSize );
    assert( whefs_fsize( F ) == truncSize );
    whefs_fseek( F, truncSize, SEEK_SET );
    whefs_file_write( F, "!!!", 3 );
    assert( whefs_fsize( F ) == (3 + truncSize) );
    whefs_fclose(F);

    whefs_fs_finalize( fs );
    MARKER("ending test\n");
    return 0;
}



int bogo()
{
    MARKER("whefs_encoded_sizeof_id_type=%d\n",whefs_sizeof_encoded_id_type);
    uint64_t i6 = UINT64_C(0x3F01020304);
    MARKER("%016llx\n",(i6 << 8) );
    MARKER("%016llx\n",(i6 >>32) );
    MARKER("%016llx\n",(i6 >>32) << 40 );
    return -1;
}

#include "whefs_encode.h"
#include <assert.h>
int test_encodings()
{
    enum { bufSize = 30 };
    unsigned char buf[bufSize];
    memset( buf, 0, bufSize );

    uint16_t ui = 27;
    size_t sz = whefs_uint16_encode( buf, ui );
    MARKER("sz=%u\n",sz);
    MARKER("Buffer bytes=");
    size_t i = 0;
    for( i = 0; i < 5; ++i )
    {
	printf("#%u=[0x%02d]\t", i, buf[i] );
    } puts("");
    uint16_t uid = (uint16_t)-1;
    int rc = whefs_uint16_decode( buf, & uid );
    MARKER("rc=%d uid=%"PRIu16"\n", rc, uid );
    MARKER("Buffer bytes=");
    for( i = 0; i < 5; ++i )
    {
	printf("#%u=[0x%02d]\t", i, buf[i] );
    } puts("");
    assert( uid == ui );
    return 0;
}

//#include "whefs_details.c"
int main( int argc, char ** argv )
{
    whefs_setup_debug( stderr );
    ThisApp.fsopts = whefs_fs_options_default;
    ThisApp.fsopts.inode_count = 8;
    ThisApp.fsopts.block_count = 32;
    ThisApp.fsopts.filename_length = 32;
    ThisApp.fsopts.block_size = 2048;
    int rc = 0;
    if(!rc) rc =  test_encodings();
    if(!rc) rc = test_one();
    if(!rc) rc =  test_ramfs();
    if(!rc) rc =  test_multiple_files();
    if(!rc) rc =  test_truncate();
    printf("Done rc=%d=[%s].\n",rc,
	   (0==rc)
	   ? "You win :)"
	   : "You lose :(");
    return rc;
}

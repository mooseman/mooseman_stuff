/*
  Author: Stephan Beal (http://wanderinghorse.net/home/stephan/)

  License: Public Domain
*/

#if ! defined __STDC_FORMAT_MACROS
/* The Linux stdint.h says:

"The ISO C99 standard specifies that these macros must only be
 defined if explicitly requested."
*/
#  define __STDC_FORMAT_MACROS 1
#endif

#include <stdlib.h>
#include <assert.h>
#include <memory.h>
#include <string.h>

#include "whefs.h"
#include "whefs_encode.h"
#include "whio_devs.h"
#include "whefs_details.c"
#include "whglob.h"

#if WHIO_FS_USE_FCNTL
#  include <fcntl.h>
#endif

char const * whefs_home_page_url()
{
    return "http://fossil.wanderinghorse.net/repos/whefs/";
}



const whefs_rc_t whefs_rc =
    {
    0, /* OK */
    1, /* ArgError */
    2, /* IOError */
    3, /* AllocError */
    4, /* BadMagicError */
    5, /* InternalError */
    6, /* RangeError */
    7, /* FSFull */
    8, /* AccessError */
    9, /* ConsistencyError */
    10, /* NYIError */
    11, /* UnsupportedError */
    (size_t)-1 /* SizeTError */
    };

const whefs_magic whefs_magic_default = WHEFS_MAGIC_DEFAULT;
const whefs_fs_options whefs_fs_options_default = WHEFS_FS_OPTIONS_DEFAULT;
const whefs_fs_options whefs_fs_options_nil = WHEFS_FS_OPTIONS_NIL;

/**
   An empty whefs_fs object for us in initializing new objects.
*/
//const whefs_fs whefs_fs_init =
#define WHEFS_FS_INIT { \
    0, /* flags */ \
    0, /* err */ \
    {0}, /* offsets */ \
    {0}, /* sizes */ \
    0, /* dev */ \
    true, /* ownsDev */ \
    0, /* filesize */ \
    0, /* opened_nodes */ \
    0, /* fileno */ \
    { /* bits */ \
	 WHBITS_INIT, /* i */ \
	 WHBITS_INIT, /* b */ \
	 0 /* memToFree */ \
    }, \
    { /* hints */ \
	1, /* unused_block_start */ \
	2 /* unused_inode_start == 2 b/c IDs 0 and 1 are reserved for not-an-inode and the root node */  \
    }, \
    WHEFS_FS_OPTIONS_DEFAULT, /* options */ \
    { /* fence */ \
	whio_blockdev_init_m /* s */, \
	whio_blockdev_init_m /* i */, \
	whio_blockdev_init_m /* b */ \
    },			   \
    {/*buffers*/ \
	{0}, /* nodeName */ \
	{0} /* inode */	  \
    } \
    } /* end of whefs_fs */
const whefs_fs whefs_fs_init = WHEFS_FS_INIT;

#if WHIO_USE_STATIC_MALLOC
enum {
/**
   The number of elements to statically allocate
   in the whefs_fs_alloc_slots object.
*/
whefs_fs_alloc_count = 2
};
static struct
{
    whefs_fs objs[whefs_fs_alloc_count];
    char used[whefs_fs_alloc_count];
    size_t next;
} whefs_fs_alloc_slots = { {WHEFS_FS_INIT}, {0}, 0 };
#endif

static whefs_fs * whefs_fs_alloc()
{
    whefs_fs * obj = 0;
#if WHIO_USE_STATIC_MALLOC
    size_t i = whefs_fs_alloc_slots.next;
    for( ; i < whefs_fs_alloc_count; ++i )
    {
	if( whefs_fs_alloc_slots.used[i] ) continue;
	whefs_fs_alloc_slots.next = i+1;
	whefs_fs_alloc_slots.used[i] = 1;
	obj = &whefs_fs_alloc_slots.objs[i];
	break;
    }
#endif /* WHIO_USE_STATIC_MALLOC */
    if( ! obj ) obj = (whefs_fs *) malloc( sizeof(whefs_fs) );
    if( obj ) *obj = whefs_fs_init;
    return obj;
}

static void whefs_fs_free( whefs_fs * obj )
{
    if( obj ) *obj = whefs_fs_init;
    else return;
#if WHIO_USE_STATIC_MALLOC
    if( (obj < &whefs_fs_alloc_slots.objs[0]) ||
	(obj > &whefs_fs_alloc_slots.objs[whefs_fs_alloc_count-1]) )
    { /* it does not belong to us */
	free(obj);
	return;
    }
    else
    {
	const size_t ndx = (obj - &whefs_fs_alloc_slots.objs[0]);
	if( whefs_fs_alloc_slots.next > ndx ) whefs_fs_alloc_slots.next = ndx;
	whefs_fs_alloc_slots.used[ndx] = 0;
	return;
    }
#else
    free(obj);
#endif /* WHIO_USE_STATIC_MALLOC */
}


int whefs_fs_lock( whefs_fs * fs, bool writeLock, off_t start, int whence, off_t len )
{
#if WHIO_FS_USE_FCNTL
    if( ! fs ) return whefs_rc.ArgError;
    //WHEFS_DBG_FYI("whefs_fs_lock(%p [fileno=%d],%d,%ld,%d,%ld)",fs,fs->fileno,writeLock,start,whence,len);
    if( fs->fileno < 1 ) return whefs_rc.UnsupportedError;
    else
    {
	struct flock lock;
	lock.l_type = writeLock ? F_WRLCK : F_RDLCK;
	lock.l_start = start;
	lock.l_whence = whence;
	lock.l_len = len;
	int rc = fcntl( fs->fileno, F_SETLKW, &lock);
        //WHEFS_DBG_FYI("whefs_fs_lock(%p,%d,%ld,%d,%ld)=%d",fs,writeLock,start,whence,len,rc);
        return rc;
    }
#else
    return whefs_rc.UnsupportedError;
#endif
}

int whefs_fs_unlock( whefs_fs * fs, off_t start, int whence, off_t len )
{
#if WHIO_FS_USE_FCNTL
    if( ! fs ) return whefs_rc.ArgError;
    if( fs->fileno < 1 ) return whefs_rc.UnsupportedError;
    else
    {
	struct flock lock;
	lock.l_type = F_UNLCK;
	lock.l_start = start;
	lock.l_whence = whence;
	lock.l_len = len;
	return( fcntl( fs->fileno, F_SETLK, &lock) );
    }
#else
    return whefs_rc.UnsupportedError;
#endif
}

int whefs_fs_lock_range( whefs_fs * fs, bool writeLock, whefs_fs_range_locker const * range )
{
    return (fs && range)
	? whefs_fs_lock( fs, writeLock, range->start, range->whence, range->len )
	: whefs_rc.ArgError;
}

int whefs_fs_unlock_range( whefs_fs * fs, whefs_fs_range_locker const * range )
{
    return (fs && range)
	? whefs_fs_unlock( fs, range->start, range->whence, range->len )
	: whefs_rc.ArgError;
}


size_t whefs_fs_read( whefs_fs * fs, void * dest, size_t n )
{
    return (fs && fs->dev)
	? fs->dev->api->read( fs->dev, dest, n )
	: 0;
}
size_t whefs_fs_write( whefs_fs * fs, void const * src, size_t n )
{
    return (fs && fs->dev)
	? fs->dev->api->write( fs->dev, src, n )
	: 0;
}

size_t whefs_fs_seek( whefs_fs * fs, size_t offset, int whence )
{
    return (fs && fs->dev)
	? fs->dev->api->seek( fs->dev, offset, whence )
	: whio_rc.SizeTError;
}

size_t whefs_fs_tell( whefs_fs * fs )
{
    return (fs && fs->dev)
	? fs->dev->api->tell( fs->dev )
	: whio_rc.SizeTError;
}

int whefs_fs_flush( whefs_fs * fs )
{
    return (fs && fs->dev)
	? fs->dev->api->flush( fs->dev )
	: whefs_rc.ArgError;
}


uint64_t whefs_bytes_hash( void const * data, uint32_t len )
{
    /**
       One-at-a-time hash code taken from:

       http://eternallyconfuzzled.com/tuts/algorithms/jsw_tut_hashing.aspx
    */
    if( ! data || !len ) return 0;
    unsigned const char *p = data;
    uint64_t h = 0;
    uint32_t i;
    for ( i = 0; i < len; i++ )
    {
	h += p[i];
	h += ( h << 10 );
	h ^= ( h >> 6 );
    }
    h += ( h << 3 );
    h ^= ( h >> 11 );
    h += ( h << 15 );
    return h;
}

/**
   tag byte for encoded whefs_id_type objects.
*/
static const unsigned int whefs_id_type_tag_char = 0x08 | 8;
size_t whefs_dev_id_encode( whio_dev * dev, whefs_id_type v )
{
#if WHEFS_ID_TYPE_BITS == 64
    return whio_dev_uint64_encode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 32
    return whio_dev_uint32_encode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 16
    return whio_dev_uint16_encode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 8
    if( ! dev ) return whefs_rc.ArgError;
    unsigned char buf[2];
    buf[0] = whefs_id_type_tag_char;
    buf[1] = v;
    return dev->api->write( dev, buf, 2 );
#else
#error "whefs_id_type size (WHEFS_ID_TYPE_BITS) is not supported!"
#endif
}

size_t whefs_id_encode( unsigned char * dest, whefs_id_type v )
{
#if WHEFS_ID_TYPE_BITS == 64
    return whefs_uint64_encode( dest, v );
#elif WHEFS_ID_TYPE_BITS == 32
    return whefs_uint32_encode( dest, v );
#elif WHEFS_ID_TYPE_BITS == 16
    return whefs_uint16_encode( dest, v );
#elif WHEFS_ID_TYPE_BITS == 8
    if( ! dest ) return whefs_rc.ArgError;
    dest[0] = whefs_id_type_tag_char;
    dest[1] = v;
    return whefs_sizeof_encoded_id_type;
#else
#error "whefs_id_type size (WHEFS_ID_TYPE_BITS) is not supported!"
#endif
}
int whefs_dev_id_decode( whio_dev * dev, whefs_id_type * v )
{
#if WHEFS_ID_TYPE_BITS == 64
    return whio_dev_uint64_decode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 32
    return whio_dev_uint32_decode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 16
    return whio_dev_uint16_decode( dev, v );
#elif WHEFS_ID_TYPE_BITS == 8
    if( ! v || ! dev ) return whefs_rc.ArgError;
    unsigned char buf[2] = {0,0};
    size_t sz = dev->api->read( dev, buf, 2 );
    if( 2 != sz)
    {
	return whefs_rc.IOError;
    }
    else if( buf[0] != whefs_id_type_tag_char )
    {
	return whefs_rc.ConsistencyError;
    }
    else
    {
	*v = buf[1];
	return whefs_rc.OK;
    }
#else
#error "whefs_id_type is not a supported type!"
#endif
}

int whefs_id_decode( unsigned char const * src, whefs_id_type * v )
{
#if WHEFS_ID_TYPE_BITS == 64
    return whefs_uint64_decode( src, v );
#elif WHEFS_ID_TYPE_BITS == 32
    return whefs_uint32_decode( src, v );
#elif WHEFS_ID_TYPE_BITS == 16
    return whefs_uint16_decode( src, v );
#elif WHEFS_ID_TYPE_BITS == 8
    if( ! src ) return whefs_rc.ArgError;
    else if( src[0] != whefs_id_type_tag_char )
    {
	return whefs_rc.ConsistencyError;
    }
    else
    {
	if( v ) *v = src[1];
    }
    return whefs_rc.OK;
#else
#error "whefs_id_type is not a supported type!"
#endif
}


typedef enum
{
WHEFS_ERR_None = 0x0000,
WHEFS_ERR_IO   = 0x10000000,
WHEFS_ERR_IO_READ   = WHEFS_ERR_IO | 0x01,
WHEFS_ERR_IO_WRITE   = WHEFS_ERR_IO | 0x02
} whefs_errors;


void whefs_fs_finalize( whefs_fs * fs )
{
    if( ! fs ) return;
    if( fs->opened_nodes )
    {
	WHEFS_FIXME("We're closing with opened inodes! We need to flush any open-for-write inodes here!");
	whefs_inode_list * l = fs->opened_nodes;
	whefs_inode_list * n = l;
	fs->opened_nodes = 0;
	while( n )
	{
	    n = l->next;
	    free(l);
	}
    }
    whio_blockdev_cleanup ( &fs->fences.s );
    whio_blockdev_cleanup ( &fs->fences.i );
    whio_blockdev_cleanup ( &fs->fences.b );
    if( fs->dev )
    {
        whefs_fs_unlock( fs, 0, SEEK_SET, 0 );
	fs->dev->api->flush( fs->dev );
	if( fs->ownsDev ) fs->dev->api->finalize( fs->dev );
	fs->dev = 0;
    }
    if( fs->bits.memToFree )
    {
	free( fs->bits.memToFree );
    }
    else
    {
	whbits_free_bits( &fs->bits.i );
	whbits_free_bits( &fs->bits.b );
    }
    whefs_fs_free( fs );
}

whefs_fs_options const * whefs_fs_options_get( whefs_fs const * fs )
{
    return fs ? &fs->options : 0;
}
whefs_fs_options const * whefs_fs_opt( whefs_fs const * fs )
{
    return fs ? &fs->options : 0;
}

const uint32_t * whefs_get_core_magic()
{
    return whefs_fs_magic_bytes;
}

char const * whefs_data_format_version_string()
{
    enum { bufLen = 60 };
    static char buf[bufLen] = {0,};
    if( ! *buf )
    {
	snprintf( buf, bufLen, "%4u-%02u-%02u with %02u-bit IDs",
		  whefs_fs_magic_bytes[0],
		  whefs_fs_magic_bytes[1],
		  whefs_fs_magic_bytes[2],
		  whefs_fs_magic_bytes[3] );
    }
    return buf;
}

/**
   Seeks to the start of fs, writes the magic bytes. Returns
   whefs_rc.OK on success.
*/
static int whefs_mkfs_write_magic( whefs_fs * fs )
{
    if( ! fs || !fs->dev ) return whefs_rc.ArgError;
    size_t pos = 0;
    fs->dev->api->seek( fs->dev, 0L, SEEK_SET );
    whio_dev_uint32_array_encode( fs->dev, whefs_fs_magic_bytes_len, whefs_fs_magic_bytes );

    /*
       TODO: double-check the expected positions again:
       
       fs->offsets[WHEFS_OFF_CORE_MAGIC]
       fs->offsets[WHEFS_OFF_CLIENT_MAGIC]
       fs->offsets[WHEFS_OFF_SIZE]
    */
    pos = (whio_dev_sizeof_uint32 * whefs_fs_magic_bytes_len);
    pos += whio_dev_uint32_encode( fs->dev, 0 /* placeholder for file size */ );
    //WHEFS_DBG("offsets[WHEFS_OFF_CLIENT_MAGIC] == %u, core magic length = %u",pos,whefs_fs_magic_bytes_len);
    pos += whio_dev_uint16_encode( fs->dev, fs->options.magic.length );
    return (0 != whio_dev_write( fs->dev, fs->options.magic.data, fs->options.magic.length ))
	? whefs_rc.OK
	: whefs_rc.IOError;
}

/**
   Writes fs->options to the current position of the stream.  Returns
   whefs_rc.OK on success.
*/
static int whefs_mkfs_write_options( whefs_fs * fs )
{
    assert( fs->dev->api->tell( fs->dev ) == fs->offsets[WHEFS_OFF_OPTIONS] );
    size_t pos = whio_dev_uint32_encode( fs->dev, fs->options.block_size );
    size_t sz = whefs_dev_id_encode( fs->dev, fs->options.block_count );
    if( whefs_sizeof_encoded_id_type != sz ) return whefs_rc.IOError;
    sz = whefs_dev_id_encode( fs->dev, fs->options.inode_count );
    if( whefs_sizeof_encoded_id_type != sz ) return whefs_rc.IOError;
    pos += whio_dev_uint16_encode( fs->dev, fs->options.filename_length );
    return (pos>0)
	? whefs_rc.OK
	: whefs_rc.IOError;
}

/**
   Returns the on-disk size of whefs_fs_options objects.
*/
static size_t whefs_fs_sizeof_options()
{
    const size_t sz = whio_dev_sizeof_uint32;
    return sz /* block_size */
	+ whefs_sizeof_encoded_id_type /* block_count */
	+ whefs_sizeof_encoded_id_type /* inode_count */
	+ whio_dev_sizeof_uint16 /* filename_length */
	;
}

static size_t whefs_fs_sizeof_name( whefs_fs_options const * opt )
{
    return !opt
	? 0
	: (whefs_sizeof_encoded_inode_name_header +  opt->filename_length);
}


#if 0 // not needed anymore?
/**
   Returns the on-disk position of the given inode's name record,
   or 0 if id is not valid for fs.
*/
static size_t whefs_name_pos( whefs_fs const * fs, whefs_id_type id )
{
    if( ! whefs_inode_id_is_valid( fs, id ) )
    {
	return 0;
    }
    else
    {
	return fs->offsets[WHEFS_OFF_INODE_NAMES]
	    + ( (id-1) * fs->sizes[WHEFS_SZ_INODE_NAME] );
    }
}
#endif

#if 0
static int whefs_fs_init_buffers( whefs_fs * fs )
{
    return whefs_rc.OK;
}
#endif

/**
   Tag byte for use in encoding inode name table entries.
*/
static unsigned char const whefs_inode_name_tag_char = 0x80 | '\'';

/**
*/
int whefs_fs_name_write( whefs_fs * fs, whefs_id_type id, char const * name )
{
    if( ! whefs_inode_id_is_valid( fs, id ) || !name)
    {
	return whefs_rc.ArgError;
    }
    uint16_t slen = 0;
    {
	char const * c = name;
	uint16_t i = 0;
	for( ; c && *c && (i < fs->options.filename_length); ++i, ++c, ++slen )
	{
	}
	if( (i == fs->options.filename_length) && *c )
	{ /** too long! */
	    return whefs_rc.RangeError;
	}
    }
    int rc = 0;
    /**
       Encode the string to a temp buffer then write it in one go to
       disk. Takes more code than plain i/o, but using the
       whio_blockdev API here means much less overall i/o, less error
       handling for the encoding (which can't fail as long as we
       provide the proper parameters and memory buffer sizes), and we
       can eventually (hopefully) add record locking into the block
       device interface.
    */
    const size_t bsz = fs->fences.s.blocks.size;
    assert(fs->sizes[WHEFS_SZ_INODE_NAME] && "fs has not been set up properly!");
    assert( bsz == fs->sizes[WHEFS_SZ_INODE_NAME] );
    unsigned char * buf = fs->buffers.nodeName;
    buf[0] = whefs_inode_name_tag_char;
    size_t off = 1;
    uint64_t shash = whefs_bytes_hash( name, slen );
    off += whefs_id_encode( buf + off, id );
    off += whefs_uint64_encode( buf + off, shash );
    off += whefs_uint16_encode( buf + off, slen );
    memcpy( buf + off, name, slen );
    unsigned char const * dbgStr = buf+off;
    off += slen;
    if( off < bsz ) memset( buf + off, 0, bsz - off );
    assert( off <= bsz );

    rc = whio_blockdev_write( &fs->fences.s, id - 1, buf );
    if( rc != whio_rc.OK )
    {
	WHEFS_DBG_ERR("Writing inode #%"WHEFS_ID_TYPE_PFMT"[%s] name failed! rc=%d bsz=%u",id,name,rc,bsz);
	return whefs_rc.IOError;
    }
    if( 0 && *name )
    {
	WHEFS_DBG("Writing inode #%"WHEFS_ID_TYPE_PFMT"[%s] name: [%s]",id,name,dbgStr);
    }
    return whefs_rc.OK;

}

int whefs_inode_name_get( whefs_fs * fs, whefs_id_type id, whefs_string * tgt )
{
    if( ! tgt || ! whefs_inode_id_is_valid( fs, id ) ) return whefs_rc.ArgError;
    int rc = 0;
    memset( fs->buffers.nodeName, 0, sizeof(fs->buffers.nodeName) );
    //fs->buffers.nodeName[0] = '*';
    const uint32_t bsz = fs->fences.s.blocks.size;
    assert( bsz == fs->sizes[WHEFS_SZ_INODE_NAME] );
    assert(fs->sizes[WHEFS_SZ_INODE_NAME] && "fs has not been set up properly!");
    rc = whio_blockdev_read( &fs->fences.s, id-1, fs->buffers.nodeName );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Error #%d reading inode #"WHEFS_ID_TYPE_PFMT"'s name record!",rc,id);
	return rc;
    }
    unsigned char const * buf = fs->buffers.nodeName;
    if( buf[0] != whefs_inode_name_tag_char )
    {
	WHEFS_DBG_ERR("Error reading inode #%"WHEFS_ID_TYPE_PFMT"'s name record! "
		      "Expected byte value 0x%02x but got 0x%02x",
		      id, whefs_inode_name_tag_char, buf[0] );
	return whefs_rc.ConsistencyError;
    }
    ++buf; // skip tag byte
    buf += whefs_sizeof_encoded_id_type //skip id field
	+ whefs_sizeof_encoded_uint64; //skip hash field
    uint16_t sl = 0;
    rc = whefs_uint16_decode( buf, &sl );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Could not decode string length token from inode #"WHEFS_ID_TYPE_PFMT"'s "
		      "name record! RC=%d",id,rc);
	return rc;
    }
    if( 0 == sl )
    {
	if( tgt->alloced )
	{
	    memset( tgt->string, 0, tgt->alloced );
	}
	tgt->length = 0;
	return whefs_rc.OK;
    }
    buf += whefs_sizeof_encoded_uint16;
    rc = whefs_string_copy_cstring( tgt, (char const *)buf );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Copying of inode #"WHEFS_ID_TYPE_PFMT"'s name record failed! "
		      "RC=%d. String is [%s]",
		      id, rc, buf );
    }
#undef DUMP
    return rc;
}

/**
   Writes the inode names table to the current position of fs->dev.
   Returns whefs_rc.OK on success.
*/
static int whefs_mkfs_write_names_table( whefs_fs * fs )
{
    whefs_id_type i = 1;
    int rc = whefs_rc.OK;
    assert( fs->dev->api->tell( fs->dev ) == fs->offsets[WHEFS_OFF_INODE_NAMES] );
    char empty[1] = {'\0'};
    for( ; (i <= fs->options.inode_count) && (whefs_rc.OK == rc); ++i )
    {
	rc = whefs_fs_name_write( fs, i, empty );
    }
    if( whefs_rc.OK == rc )
    {
	// Unfortunate workaround for expectations of mkfs...
	whefs_fs_seek( fs, fs->offsets[WHEFS_OFF_INODES_NO_STR], SEEK_SET );
    }
    return rc;
}



size_t whefs_fs_calculate_size( whefs_fs_options const * opt )
{
    static const size_t sz = whio_dev_sizeof_uint32;
    if( ! opt ) return 0;
    else return
	(whio_dev_sizeof_uint32 * whefs_fs_magic_bytes_len) // core magic
	+ sz // file size header
	+ whio_dev_sizeof_uint16 // client magic size
	+ opt->magic.length
	+ whefs_fs_sizeof_options()
	+ (whefs_fs_sizeof_name( opt ) * opt->inode_count)/* inode names table */
	+ (whefs_sizeof_encoded_inode * opt->inode_count) /* inode table */
	+ (whefs_fs_sizeof_block( opt ) * opt->block_count)/* blocks table */
	;
}


/**
   Writes all (empty) blocks of fs to the current position of the data
   store.  Returns whefs_rc.OK on success.
*/
static int whefs_mkfs_write_blocklist( whefs_fs * fs )
{
    whefs_id_type i = 0;
    int rc = whefs_rc.OK;
    assert( fs->dev->api->tell( fs->dev ) == fs->offsets[WHEFS_OFF_BLOCKS] );
    whefs_block bl = whefs_block_init;
    for( i = 1; (i <= fs->options.block_count) && (whefs_rc.OK == rc); ++i )
    {
	bl.id = i;
	if( whefs_rc.OK != (rc = whefs_block_wipe( fs, &bl, true, true, false )) )
	{
	    WHEFS_DBG_ERR("Error %d while writing the block table!", rc);
	    break;
	}
    }
    return rc;
}

/**
   Writes all (empty) inodes to the current position of
   fs->dev. Returns whefs_rc.OK on success.
*/
static int whefs_mkfs_write_inodelist( whefs_fs * fs )
{
    size_t i = 0;
    int rc = whefs_rc.OK;
    whefs_inode node = whefs_inode_init;
    for( i = 1; (i <= fs->options.inode_count) && (whefs_rc.OK == rc); ++i )
    {
	node.id = i;
	rc = whefs_inode_encode( fs->buffers.inode, &node );
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("Error #%d while encoding new-style inode #%"WHEFS_ID_TYPE_PFMT"!",
			  rc,i);
	    return rc;
	}
	rc = whio_blockdev_write( &fs->fences.i, i-1, fs->buffers.inode );
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("Error #%d while writing new-style inode #%"WHEFS_ID_TYPE_PFMT"!",
			  rc, i);
	    return rc;
	}
    }
    whefs_fs_seek( fs, fs->offsets[WHEFS_OFF_BLOCKS], SEEK_SET ); /* workaround for mkfs() expectations. */
    return rc;
}


/**
   Uses whio_dev_ioctl() to try to get a file descriptor number
   associated with fs->dev. If it succeeds we store the descriptor
   so we can later use it to implement file locking.
*/
static void whefs_fs_check_fileno( whefs_fs * fs )
{
    if( fs && fs->dev )
    {
	char const * fname = 0;
	whio_dev_ioctl( fs->dev, whio_dev_ioctl_GENERAL_name, &fname );
	if( whio_rc.OK == whio_dev_ioctl( fs->dev, whio_dev_ioctl_FILE_fd, &fs->fileno ) )
	{
	    //WHEFS_DBG_FYI("Backing store appears to be a FILE (named [%s]) with descriptor #%d.", fname, fs->fileno );
	    //posix_fadvise( fs->fileno, 0L, 0L, POSIX_FADV_RANDOM );
	}
	else
	{
	    //WHEFS_DBG("Backing store does not appear to be a FILE." );
	}
    }
}

/**
   Opens filename in read-write mode (if writeMode is true) or read-only mode
   (if writeMode is 0) and assigns fs->dev to that device. Returns the new
   whio_dev object, which is owned by fs. Any existing fs->dev object
   is destroyed. On error, 0 is returned.
*/
static whio_dev * whefs_open_FILE( char const * filename, whefs_fs * fs, bool writeMode )
{
    if( ! filename || !fs ) return 0;
    if( fs->dev )
    {
	fs->dev->api->finalize( fs->dev );
	fs->dev = 0;
    }
    fs->dev = whio_dev_for_filename( filename, writeMode ? "r+b" : "rb" );
    if( writeMode && !fs->dev )
    { /* didn't exist (we assume), so try to create it */
	//WHEFS_DBG("Opening [%s] with 'r+' failed. Trying 'w+'...", filename );
	fs->dev = whio_dev_for_filename( filename, "w+b" );
    }
    if( ! fs->dev ) return 0;
    whefs_fs_check_fileno( fs );
    int lk = whefs_fs_lock( fs, writeMode, 0, SEEK_SET, 0 );
    if( (whefs_rc.OK == lk) || (whefs_rc.UnsupportedError == lk) )
    {
        // okay
    }
    else
    {
        fs->dev->api->finalize( fs->dev );
        fs->dev = 0;
    }
    return fs->dev;
}

/**
   Initializes the internal bitset caches. It must not be called
   before fs has a device and a filesystem has been opened. If called
   more than once for the same fs, the second and subsequent calls
   succeed but do nothing. Does not do any I/O.

   Returns whefs_rc.OK on success.
*/
static int whefs_fs_init_bitsets( whefs_fs * fs )
{
#if WHEFS_FS_BITSET_CACHE_ENABLED
    //WHEFS_DBG("Setting up bitsets for fs@0x%p", (void const *)fs );
    if( ! fs ) return whefs_rc.ArgError;
    const size_t nbits = 1; /* flags: used */
    const size_t bbits = 1; /* flag: used */
    const size_t nbc = fs->options.inode_count * nbits + 1; /* +1 b/c we use the ID (1...N) as bit address */
    const size_t bbc = fs->options.block_count * bbits + 1; /* +1 b/c we use the ID (1...N) as bit address */
#if 1
    const size_t nbytes = (nbc / 8) + ((nbc%8) ? 1 : 0);
    const size_t bbytes = (bbc / 8) + ((bbc%8) ? 1 : 0);
    const size_t msz = nbytes + bbytes;
    fs->bits.memToFree = (unsigned char *)malloc( msz );
    if( ! fs->bits.memToFree ) return whefs_rc.AllocError;
    fs->bits.i.bytes = fs->bits.memToFree;
    fs->bits.i.sz_bytes = nbytes;
    fs->bits.i.sz_bits = nbc;
    fs->bits.b.bytes = fs->bits.memToFree + nbytes;
    fs->bits.b.sz_bytes = bbytes;
    fs->bits.b.sz_bits = bbc;
#else
    //WHEFS_DBG("Initializing bitsets. Node count/bits/bytes=%u/%u/%u, block count/bits/bytes=%u/%u/%u", fs->options.inode_count, nbc, nbytes, fs->options.block_count, bbc, bbytes  );
    if( 0 != whbits_init( &fs->bits.i, nbc, 0 ) ) return whefs_rc.AllocError;
    if( 0 != whbits_init( &fs->bits.b, bbc, 0 ) ) return whefs_rc.AllocError;
    fs->bits.memToFree = 0;
#endif
#if 0
    WHEFS_DBG("Initialized bitsets. Node count/bits/bytes=%u/%u/%u, block count/bits/bytes=%u/%u/%u",
	      fs->options.inode_count, fs->bits.i.sz_bits, fs->bits.i.sz_bytes, fs->options.block_count, fs->bits.b.sz_bits, fs->bits.b.sz_bytes );
#endif
    WHEFS_ICACHE_SET_USED(fs,0); /* inode ID 0 is reserved for "not a node". */
    WHEFS_ICACHE_SET_USED(fs,1); /* inode ID 1 is reserved for the root node. */
#endif /* WHEFS_FS_BITSET_CACHE_ENABLED */
    return whefs_rc.OK;
}

/**
   Initializes the internal inode cache, reading the state from
   storage.

   Returns whefs_rc.OK on success.
*/
static int whefs_fs_inode_cache_load( whefs_fs * fs )
{
#if WHEFS_FS_BITSET_CACHE_ENABLED
    if( ! fs || !fs->dev ) return whefs_rc.ArgError;
    //return 0;
    const whefs_id_type nc = whefs_fs_options_get(fs)->inode_count;
    whefs_id_type id = 2; // root node (id=1) is always considered used
    int rc = 0;
    uint32_t flags;
    whefs_id_type count = 0;
    whefs_inode ino = whefs_inode_init;
    for( ; id <= nc; ++id )
    {
	//WHEFS_DBG("Trying to cache inode #%"WHEFS_ID_TYPE_PFMT"'s state.", id);
	ino.id = id;
	flags = 0;
	rc = whefs_inode_read( fs, &ino );
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("Error #%d while reading inode #%"WHEFS_ID_TYPE_PFMT"!", rc, id);
	    return rc;
	}
	if( ino.flags & WHEFS_FLAG_Used )
	{
	    ++count;
	    WHEFS_ICACHE_SET_USED(fs,id);
	}
	else
	{
	    WHEFS_ICACHE_UNSET_USED(fs,id);
	}
    }
    //WHEFS_DBG_FYI("Initialized inode cache (entries: %u)", count);
#endif /* WHEFS_FS_BITSET_CACHE_ENABLED */
    return whefs_rc.OK;
}

/**
   Loads the block cache. Returns whefs_rc.OK on success,
*/
static int whefs_fs_block_cache_load( whefs_fs * fs )
{
#if WHEFS_FS_BITSET_CACHE_ENABLED
    /* FIXME: instead of using whefs_block_read(), simply extract the
       flags field from each block entry. That'll be much faster. */
    if( ! fs || !fs->dev ) return whefs_rc.ArgError;
    //return 0;
    const size_t bc = whefs_fs_options_get(fs)->block_count;
    size_t id = 1;
    int rc = 0;
    whefs_block bl;
    for( ; id <= bc; ++id )
    {
	bl = whefs_block_init;
	bl.id = id;
	rc = whefs_block_read( fs, &bl ); /* this will update the used-blocks cache */
	if( whefs_rc.OK != rc )
	{
	    WHEFS_DBG_ERR("Error #%d while reading block #%u!", rc, id);
	    return rc;
	}
	//WHEFS_DBG("block cache. #%u is %s",bl.id, (WHEFS_BCACHE_IS_USED(fs,id) ? "used" : "unused") );
    }
    //WHEFS_DBG("Initialized block cache.");
#endif /* WHEFS_FS_BITSET_CACHE_ENABLED */
    return whefs_rc.OK;
}

/**
   Loads the inode and block caches. Returns whefs_rc.OK on success,
*/
static int whefs_fs_caches_load( whefs_fs * fs )
{
    int rc = whefs_fs_inode_cache_load( fs );
    if( whefs_rc.OK == rc ) rc = whefs_fs_block_cache_load( fs );
    return rc;
}

/**
   Initializes fs->sizes[] and fs->offsets[]. fs->options must have
   been populated in order for this to work.
*/
static void whefs_fs_init_sizes( whefs_fs * fs )
{
    fs->sizes[WHEFS_SZ_INODE_NO_STR] = whefs_sizeof_encoded_inode;
    fs->sizes[WHEFS_SZ_INODE_NAME] = whefs_fs_sizeof_name( &fs->options );
    fs->sizes[WHEFS_SZ_BLOCK] = whefs_fs_sizeof_block( &fs->options );
    fs->sizes[WHEFS_SZ_OPTIONS] = whefs_fs_sizeof_options();

    fs->offsets[WHEFS_OFF_CORE_MAGIC] = 0;

    size_t sz =	/* core magic len */
	(whefs_sizeof_encoded_uint32 * whefs_fs_magic_bytes_len);

    fs->offsets[WHEFS_OFF_SIZE] =
	fs->offsets[WHEFS_OFF_CORE_MAGIC]
	+ sz;
    sz = /* file size */
	whefs_sizeof_encoded_uint32;

    fs->offsets[WHEFS_OFF_CLIENT_MAGIC] =
	fs->offsets[WHEFS_OFF_SIZE]
	+ sz;
    sz = /* client magic size */
	whefs_sizeof_encoded_uint16 // length
	+ fs->options.magic.length;

    fs->offsets[WHEFS_OFF_OPTIONS] = 
	fs->offsets[WHEFS_OFF_CLIENT_MAGIC]
	+ sz;

    fs->offsets[WHEFS_OFF_INODE_NAMES] =
	fs->offsets[WHEFS_OFF_OPTIONS]
	+ fs->sizes[WHEFS_SZ_OPTIONS];
    sz = /* names table size */
	(fs->options.inode_count * fs->sizes[WHEFS_SZ_INODE_NAME]);

    fs->offsets[WHEFS_OFF_INODES_NO_STR] =
	fs->offsets[WHEFS_OFF_INODE_NAMES]
	+ sz;
    sz = /* new inodes table size */
	(fs->options.inode_count * fs->sizes[WHEFS_SZ_INODE_NO_STR]);

    //fs->offsets[WHEFS_OFF_BLOCK_TABLE] NYI

    fs->offsets[WHEFS_OFF_BLOCKS] =
	fs->offsets[WHEFS_OFF_INODES_NO_STR]
	+ sz;
    sz = /* blocks table size */
	(fs->options.block_count * fs->sizes[WHEFS_SZ_BLOCK]);

    fs->offsets[WHEFS_OFF_EOF] =
	fs->offsets[WHEFS_OFF_BLOCKS]
	+ sz;

#if 0
    fprintf( stdout, "\tOffsets:\n");
#define OFF(X) fprintf(stdout,"\t\tfs->offsets[%s]\t= %u\n",# X, fs->offsets[WHEFS_OFF_ ## X])
    OFF(CORE_MAGIC);
    OFF(SIZE);
    OFF(CLIENT_MAGIC);
    OFF(OPTIONS);
    OFF(INODE_NAMES);
    OFF(INODES);
    OFF(BLOCKS);
    OFF(EOF);
#undef OFF
#define OFF(X) fprintf(stdout,"\t\tfs->sizes[%s]\t= %u\n",# X, fs->sizes[WHEFS_SZ_ ## X])
    OFF(INODE);
    OFF(INODE_NAME);
    OFF(BLOCK);
    OFF(OPTIONS);
    fflush(stdout);
    //assert(0 && "on purpose");
#undef OFF
#endif
}

static unsigned char whefs_block_name_prototype[WHEFS_MAX_FILENAME_LENGTH + 30 /* FIXME: use proper offset here*/] = {'*',0};
/** @internal
   Initializes several i/o fencing devices for fs. fs->dev must be valid
   and whefs_fs_init_sizes() must have been falled.

   Returns whefs_rc.OK on success.
*/
static int whefs_fs_init_fences( whefs_fs * fs )
{
    if( ! fs || !fs->dev || !fs->offsets[WHEFS_OFF_BLOCKS] ) return whefs_rc.ArgError;
    if( '*' == whefs_block_name_prototype[0] )
    {
	memset( whefs_block_name_prototype + 1, 0, WHEFS_MAX_FILENAME_LENGTH - 1 );
	whefs_block_name_prototype[0] = 0;
    }
    int rc = whefs_rc.OK;

    rc = whio_blockdev_setup( &fs->fences.s, fs->dev,
				  fs->offsets[WHEFS_OFF_INODE_NAMES],
				  fs->sizes[WHEFS_SZ_INODE_NAME],
				  fs->options.inode_count,
				  whefs_block_name_prototype );
    if( whio_rc.OK != rc ) return rc;

    rc = whio_blockdev_setup( &fs->fences.i, fs->dev,
			      fs->offsets[WHEFS_OFF_INODES_NO_STR],
			      fs->sizes[WHEFS_SZ_INODE_NO_STR],
			      fs->options.inode_count,
			      0 );
    if( whio_rc.OK != rc ) return rc;

#if 0 // not yet used...
    rc = whio_blockdev_setup( &fs->fences.b, fs->dev,
			      fs->offsets[WHEFS_OFF_BLOCKS],
			      fs->sizes[WHEFS_SZ_BLOCK],
			      fs->options.block_count,
			      0 /* FIXME: we need a prototype, but need the encoding routines for that first. */ );
#endif
    return rc;
}


/**
   Sets up a new, whefs_fs object an initializes the parts which depend only
   on the options. On success tgt is assigned to the new device and whefs_rc.OK
   is returned. On error, tgt is not modified and some other value is returned.
*/
static int whefs_mkfs_stage1( whefs_fs_options const * opt, whefs_fs ** tgt )
{
    if( !opt || !tgt ) return whefs_rc.ArgError;
    if( (opt->inode_count < 2)
	|| (opt->block_size < 32)
	|| !opt->filename_length
	|| (opt->filename_length > WHEFS_MAX_FILENAME_LENGTH)
	|| !opt->magic.length
	|| !opt->magic.data
	|| (opt->block_count < opt->inode_count)
	)
    {
	return whefs_rc.RangeError;
    }
    whefs_fs * fs = whefs_fs_alloc();
    if( ! fs ) return whefs_rc.AllocError;
    *fs = whefs_fs_init;
    fs->flags = WHEFS_FLAG_ReadWrite;
    fs->options = *opt;

    whefs_fs_init_sizes( fs );

    int rc = whefs_fs_init_bitsets( fs );
    if( whefs_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Init of bitsets failed with rc %d!", rc);
	whefs_fs_finalize( fs );
	return rc;
    }
    *tgt = fs;

    return whefs_rc.OK;
}

/**
   Writes out the disk structures for mkfs. fs->dev must be valid.  On
   success whefs_rc.OK is returned. On error, fs is destroyed and some
   other value is returned.
*/
static int whefs_mkfs_stage2( whefs_fs * fs )
{
    if( ! fs || !fs->dev ) return whefs_rc.ArgError;

    size_t szcheck = whefs_fs_calculate_size(&fs->options);
    //WHEFS_DBG("szcheck = %u", szcheck );

    int rc = fs->dev->api->truncate( fs->dev, szcheck );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Could not truncate VFS container to %u bytes!", szcheck );
	whefs_fs_finalize( fs );
	return rc;
    }

    rc = whefs_fs_init_fences( fs );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Internal error: could not initialize i/o fences! rc=%d", rc );
	whefs_fs_finalize( fs );
	return rc;
    }

    //size_t bogo = 0;
#define CHECKRC if( rc != whefs_rc.OK ) { whefs_fs_finalize(fs); return rc; } \
    /*bogo= whio_dev_size( fs->dev ); WHEFS_DBG("device size=[%u]", bogo );*/

    // The following orders are important, as fs->offsets[] is used to confirm
    // expected file positions.
    rc = whefs_mkfs_write_magic( fs );
    CHECKRC;
    rc = whefs_mkfs_write_options( fs );
    CHECKRC;
    rc = whefs_mkfs_write_names_table( fs );
    CHECKRC;
    rc = whefs_mkfs_write_inodelist( fs );
    CHECKRC;
    rc = whefs_mkfs_write_blocklist( fs );
    CHECKRC;
#undef CHECKRC
    fs->dev->api->flush( fs->dev );
    fs->filesize = whio_dev_size( fs->dev );
    //WHEFS_DBG("File size is(?) %u", fs->filesize );

    szcheck = whefs_fs_calculate_size(&fs->options);
    if( szcheck != fs->filesize )
    {
	WHEFS_DBG_ERR("VFS size error: the calculated size (%u) does not match the real size (%u)!", szcheck, fs->filesize );
	whefs_fs_finalize( fs );
	return whefs_rc.ConsistencyError;
    }
    fs->offsets[WHEFS_OFF_EOF] = fs->dev->api->tell( fs->dev );
    fs->dev->api->seek( fs->dev, fs->offsets[WHEFS_OFF_SIZE], SEEK_SET );
    whio_dev_uint32_encode( fs->dev, fs->filesize );

    fs->dev->api->flush( fs->dev );
    return whefs_rc.OK;
}

int whefs_mkfs( char const * filename, whefs_fs_options const * opt, whefs_fs ** tgt )
{
    if( ! filename || !opt || !tgt ) return whefs_rc.ArgError;
    whefs_fs * fs = 0;
    int rc = whefs_mkfs_stage1( opt, &fs );
    if( whefs_rc.OK != rc ) return rc;

    if( 0 == strcmp(":memory:",filename) )
    {
	if( ! (fs->dev = whio_dev_for_membuf( whefs_fs_calculate_size(opt), 0 )) )
	{
	    whefs_fs_finalize(fs);
	    return whefs_rc.AllocError; /* we're guessing here. */
	}
    }
    else if( ! whefs_open_FILE( filename, fs, true ) )
    {
	whefs_fs_finalize(fs);
	return whefs_rc.AccessError;
    }
    if( ! fs->dev )
    {
	whefs_fs_finalize(fs);
	return whefs_rc.InternalError;
    }
    rc = whefs_mkfs_stage2( fs );
    if( whefs_rc.OK != rc )
    {
	/* fs is already destroyed */
	fs = 0;
    }
    else
    {
	*tgt = fs;
    }
    return rc;
}

int whefs_mkfs_dev( whio_dev * dev, whefs_fs_options const * opt, whefs_fs ** tgt, bool takeDev )
{
    if( ! dev || !opt || !tgt ) return whefs_rc.ArgError;
    whefs_fs * fs = 0;
    int rc = whefs_mkfs_stage1( opt, &fs );
    if( whefs_rc.OK != rc ) return rc;
    fs->ownsDev = false;
    fs->dev = dev;
    rc = whefs_mkfs_stage2( fs );
    if( whefs_rc.OK != rc )
    {
	WHEFS_DBG_ERR("mkfs stage 2 failed with rc %d!",rc);
	/* fs was already destroyed */
	fs = 0;
    }
#if 0
    // FIXME: we don't yet have the in-use cache for devices opened using mkfs!
    /* weird. When i do this here i get read() errors in the file-based i/o handler,
       with read() reporting that errno==EBADF (bad file descriptor)!!!

       i think it's because of how we're opening the file (with
       "w+"). The workaround may be to close the VFS and
       re-whefs_fsopen_dev() it.
    */
    rc = whefs_fs_caches_load( fs );
    if( whefs_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Could not initialize VFS caches! Error code=%d.",rc);
	whefs_fs_finalize( fs );
	fs = 0;
    }
#endif
    if( fs )
    {
	fs->ownsDev = takeDev;
	*tgt = fs;
    }
    return rc;
}

/**
   Performs the final stage of opening a vfs. fs must have been
   initialized and fs->dev must have been set up.

   On error, fs will be destroyed and non-whefs_rc.OK will be
   returned.

   fs will be modified quite significantly here, but this stuff must
   be called before the vfs can be used.
*/
static int whefs_openfs_stage2( whefs_fs * fs )
{
    if( ! fs ) return whefs_rc.ArgError;

    fs->offsets[WHEFS_OFF_CORE_MAGIC] = 0;
    fs->offsets[WHEFS_OFF_SIZE] = (whefs_fs_magic_bytes_len * whio_dev_sizeof_uint32);
    int rc = whefs_rc.OK;
    uint32_t coreMagic[whefs_fs_magic_bytes_len];

    while(1)
    {
	if( whefs_fs_magic_bytes_len != whio_dev_uint32_array_decode( fs->dev, whefs_fs_magic_bytes_len, coreMagic ) )
	{
	    WHEFS_DBG_ERR("Error reading the core magic bytes.");
	    rc = whefs_rc.BadMagicError;
	    break;
	}
	//WHEFS_DBG("Core magic = %04u %02u %02u %02u", coreMagic[0], coreMagic[1], coreMagic[2], coreMagic[3] );
	size_t i = 0;
	for( ; i < whefs_fs_magic_bytes_len; ++i )
	{
	    if( coreMagic[i] != whefs_fs_magic_bytes[i] )
	    {
		WHEFS_DBG_ERR("Core magic byte #%u does not match the expected value of 0x%04x (%u).",
			      i, whefs_fs_magic_bytes[i], whefs_fs_magic_bytes[i] );
		rc = whefs_rc.BadMagicError;
		break;
	    }
	}
	break;
    }
    if( rc != whefs_rc.OK )
    {
	whefs_fs_finalize(fs);
	return rc;
    }

    uint32_t fsize = 0;
    rc = whio_dev_uint32_decode( fs->dev, &fsize );
    if( whefs_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Doesn't seem to be a whefs file! error code=%d",rc);
	whefs_fs_finalize( fs );
	return whefs_rc.BadMagicError;
    }
    fs->filesize = fsize;
    fs->offsets[WHEFS_OFF_CLIENT_MAGIC] = fs->dev->api->tell(fs->dev);
    size_t aSize = whio_dev_size( fs->dev );
    if( !fsize || !aSize || (aSize != fsize) )
    { /* reminder: (aSize > fsize) must be allowed for static memory buffers to be usable as i/o devices. */
	WHEFS_DBG_ERR("File sizes don't agree: expected %u but got %u", fsize, aSize );
	whefs_fs_finalize( fs );
	return whefs_rc.ConsistencyError;
    }
    fs->offsets[WHEFS_OFF_EOF] = fsize;

#define CHECK if( whefs_rc.OK != rc ) { whefs_fs_finalize(fs); WHEFS_DBG_WARN("Decode of vfs options failed!"); return rc; }
    whefs_fs_options * opt = &fs->options;
    *opt = whefs_fs_options_nil;
    /* Read FS options... */
    // FIXME: factor this out into whefs_options_read():
    fs->dev->api->seek( fs->dev, fs->offsets[WHEFS_OFF_CLIENT_MAGIC], SEEK_SET );
    rc = whio_dev_uint16_decode( fs->dev, &opt->magic.length );
    CHECK;
    ///fs->offsets[WHEFS_OFF_OPTIONS] = 
    fs->dev->api->seek( fs->dev, opt->magic.length, SEEK_CUR );
    /* FIXME: store the opt->magic.data somewhere! Ownership requires some changes in other code. */
    rc = whio_dev_uint32_decode( fs->dev, &opt->block_size );
    CHECK;
    rc = whefs_dev_id_decode( fs->dev, &opt->block_count );
    CHECK;
    rc = whefs_dev_id_decode( fs->dev, &opt->inode_count );
    CHECK;
    rc = whio_dev_uint16_decode( fs->dev, &opt->filename_length );
    CHECK;
#undef CHECK
    whefs_fs_init_sizes( fs );
    rc = whefs_fs_init_fences( fs );
    if( whio_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Internal error: could not initialize i/o fences!" );
	whefs_fs_finalize( fs );
	return rc;
    }

    rc = whefs_fs_init_bitsets( fs );
    if( whefs_rc.OK != rc )
    {
	/* we could treat this as non-fatal we we changed how
	   cache-is-on checking is done elsewhere. */
	WHEFS_DBG_ERR("Init of bitsets failed with rc %d!", rc);
	whefs_fs_finalize( fs );
	return rc;
    }

    rc = whefs_fs_caches_load( fs );
    if( whefs_rc.OK != rc )
    {
	WHEFS_DBG_ERR("Error #%d initializing inode/block caches!", rc);
	whefs_fs_finalize( fs );
	return rc;
    }
    return whefs_rc.OK;
}

int whefs_openfs_dev( whio_dev * dev, whefs_fs ** tgt, bool takeDev )
{
    if( ! dev || !tgt ) return whefs_rc.ArgError;
    whefs_fs * fs = whefs_fs_alloc();
    if( ! fs ) return whefs_rc.AllocError;
    *fs = whefs_fs_init;
    // FIXME: do a 1-byte write test to see if the device is writeable,
    // or add a parameter to the function defining the write mode.
    fs->flags = WHEFS_FLAG_ReadWrite; /* we're guessing!!! */
    fs->dev = dev;
    fs->ownsDev = takeDev;
    whefs_fs_check_fileno( fs );
    int rc = whefs_openfs_stage2( fs );
    if( whefs_rc.OK == rc )
    {
	*tgt = fs;
    }
    return rc;
}

int whefs_openfs( char const * filename, whefs_fs ** tgt, bool writeMode )
{
    // FIXME: refactor this to take a whio_dev and split it into
    // two or three parts.
    if( ! filename || !tgt ) return whefs_rc.ArgError;
    whefs_fs * fs = whefs_fs_alloc();
    if( ! fs ) return whefs_rc.AllocError;
    *fs = whefs_fs_init;
    fs->flags = (writeMode ? WHEFS_FLAG_ReadWrite : WHEFS_FLAG_Read);
    if( ! whefs_open_FILE( filename, fs, writeMode ) )
    {
	WHEFS_DBG_WARN("Could not open file [%s] in %s mode.",
		       filename, writeMode ? "read/write" : "read-only" );
	whefs_fs_free(fs);
	return whefs_rc.IOError;
    }
    int rc = whefs_openfs_stage2( fs );
    if( whefs_rc.OK == rc )
    {
	*tgt = fs;
    }
    return rc;
}

int whefs_fs_dump_to_FILE( whefs_fs * fs, FILE * out )
{
    if( ! fs || !out || !fs->dev ) return whefs_rc.ArgError;
    int rc = whefs_rc.OK;
    enum { bufSize = (1024 * 4) };
    unsigned char buf[bufSize];
    size_t rlen = 0;
    fs->dev->api->seek( fs->dev, 0L, SEEK_SET );
    while( (rlen = fs->dev->api->read( fs->dev, buf, bufSize ) ) )
	//#undef bufSize
    {
	if( 1 != fwrite( buf, rlen, 1, out ) )
	{
	    rc = whefs_rc.IOError;
	    break;
	}
    }
    return rc;
}

int whefs_import( whefs_fs * fs, whio_dev * src, char const * fname, bool overwrite )
{
    if( ! fs || !src || !fname || !*fname ) return whefs_rc.ArgError;
    int rc = whefs_rc.OK;
    whefs_inode ino = whefs_inode_init;
    bool existed = false;
    rc = whefs_inode_by_name( fs, fname, &ino );
    if( rc == whefs_rc.OK )
    {
	if( ! overwrite ) return whefs_rc.AccessError;
	existed = true;
    }
    else
    {
	rc = whefs_inode_next_free( fs, &ino, true );
	if( whefs_rc.OK != rc ) return rc;
	rc = whefs_inode_name_set( fs, &ino, fname );
	if( whefs_rc.OK != rc ) return rc;
	whefs_inode_flush( fs, &ino );
    }
    whio_dev * imp = whefs_dev_for_inode( fs, ino.id, true );
    if( ! imp ) return whefs_rc.InternalError;

    const size_t oldPos = src->api->tell( src );
    const size_t szrc = src->api->seek( src, 0, SEEK_SET );
    if( whio_rc.SizeTError == szrc )
    {
	imp->api->finalize( imp );
	if( ! existed )
	{
	    whefs_inode_unlink( fs, &ino );
	}
	return whefs_rc.RangeError;
    }

    const size_t oldFSize = ino.data_size;
    const size_t newFSize = whio_dev_size( src );
    rc = imp->api->truncate( imp, newFSize );
    if( rc != whefs_rc.OK )
    {
	WHEFS_DBG_ERR("Could not truncate '%s' to %u bytes!", fname, newFSize );
	imp->api->truncate( imp, oldFSize );
	src->api->seek( src, oldPos, SEEK_SET );
	imp->api->finalize( imp );
	if( ! existed )
	{
	    whefs_inode_unlink( fs, &ino );
	}
	return rc;
    }
    imp->api->flush( imp );
    if( 0 == newFSize )
    {
	//WHEFS_DBG("Importing 0-byte file.");
	src->api->seek( src, oldPos, SEEK_SET );
	imp->api->finalize(imp);
	return whefs_rc.OK;
    }
    enum { bufSize = 1024 * 4 };
    unsigned char buf[bufSize];
    memset( buf, 0, bufSize );
    size_t wlen = newFSize;
    size_t totalR = 0;
    size_t totalW = 0;
    size_t rrc = 0;
    size_t wrc = 0;
    imp->api->seek( imp, 0, SEEK_SET );
    do
    {
	rrc = src->api->read( src, buf, bufSize );
	totalR += rrc;
	if( ! rrc ) break;
	if( (wlen - rrc) > wlen )
	{
	    WHEFS_DBG_ERR("Read an unexpected length (%u)! Continuing would cause an underflow!", rrc);
	    break;
	}
	wlen -= rrc;
	wrc = imp->api->write( imp, buf, rrc );
	//WHEFS_DBG("wrc=%u, rrc=%u, xoimp->tell=%u",wrc, rrc, imp->api->tell(imp));
	totalW += wrc;
	if( wrc != rrc ) break;
    }
    while( rrc && wrc );
    src->api->seek( src, oldPos, SEEK_SET );
    const size_t impSize = whio_dev_size( imp );
    imp->api->finalize(imp);
    imp = 0;
    rc = whefs_rc.OK;
    if( totalR != totalW )
    {
	WHEFS_DBG_ERR("Pseudofile [%s]: Total read bytes (%u) != total written bytes (%u)", fname, totalR, totalW );
	rc = whefs_rc.IOError;
    }
    else if( impSize != newFSize )
    {
	WHEFS_DBG_ERR("Pseudofile [%s]: Imported file size (%u) does not match the source's size (%u)", fname, totalR, totalW );
	rc = whefs_rc.IOError;
    }
    if( whefs_rc.OK != rc )
    {
	if( ! existed )
	{
	    whefs_inode_unlink( fs, &ino );
	}
    }
    return rc;
}

int whefs_fs_dump_to_filename( whefs_fs * fs, char const * filename )
{
    if( ! fs || !filename || !fs->dev ) return whefs_rc.ArgError;
    FILE * f = fopen( filename, "w+" );
    if( ! f ) return whefs_rc.AccessError;
    int rc = whefs_fs_dump_to_FILE( fs, f );
    fclose( f );
    return rc;
}


void whefs_fs_dump_info( whefs_fs const * fs, FILE * out )
{
    struct SizeOfs
    {
	char const * label;
	size_t size;
    } sizeofs[] = {
#define X(T) {"sizeof(" # T ")",sizeof(T)}
    X(whefs_fs),
    X(whio_dev),
    X(whio_dev_api),
#if 0
    X(whio_stream),
    X(whio_stream_api),
#endif
    X(whefs_inode),
    X(whefs_block),
    X(whefs_file),    
    {0,0}
    };
#undef X

    fprintf( out,"%s:%d:%s():\n", __FILE__, __LINE__, __func__);

    struct SizeOfs * so = sizeofs;
    fprintf( out, "sizeof() of various internal types:\n");
    for( ;so && so->label; ++so )
    {
	fprintf( out,"\t%s = %u\n", so->label, so->size );
    }



    fprintf( out,"Various VFS stats:\n" );
    whefs_fs_options const * o = &fs->options;
    fprintf( out,
	     "\ton-disk sizeof whefs_inode = %u (+%u bytes for the name)\n"
	     "\tbits used for node/block IDs: %u\n"
	     "\tblock size: %u\n"
	     "\tblock count: %"WHEFS_ID_TYPE_PFMT"\n"
	     "\tmax inode count: %"WHEFS_ID_TYPE_PFMT" (1 is reserved for the root dir entry!)\n"
	     "\tmax filename length: %u (WHEFS_MAX_FILENAME_LENGTH=%u)\n"
	     "\tmagic cookie length: %u\n"
	     "\tContainer size:\n\t\tcalculated =\t\t%u\n\t\tdevice-reported =\t%"WHIO_SIZE_T_PFMT"\n",
	     whefs_sizeof_encoded_inode, whefs_fs_sizeof_name(&fs->options),
	     WHEFS_ID_TYPE_BITS,
	     o->block_size,
	     o->block_count,
	     o->inode_count,
	     o->filename_length, WHEFS_MAX_FILENAME_LENGTH,
	     o->magic.length,
	     whefs_fs_calculate_size(&fs->options),
	     whio_dev_size(fs->dev)
	     );
#if 1
    fprintf( out, "\tVFS internal table offsets:\n");
#define OFF(X) fprintf(out,"\t\t%s\t= %u\n",# X, fs->offsets[WHEFS_OFF_ ## X])
    OFF(CORE_MAGIC);
    OFF(SIZE);
    OFF(CLIENT_MAGIC);
    OFF(OPTIONS);
    OFF(INODE_NAMES);
    OFF(INODES_NO_STR);
    OFF(BLOCKS);
    OFF(EOF);
#undef OFF
#endif

}

int whefs_fs_stats_get( whefs_fs * fs, whefs_fs_stats * st )
{
    if( ! fs || ! st ) return whefs_rc.ArgError;
    WHEFS_DBG_ERR("NYI!");

    st->size = fs->filesize;
    // FIXME: calculate used nodes.
    st->used_inodes = 1; /* root node is always considered used. */
    // FIXME: calculate used blocks
    st->used_blocks = 0;
    // FIXME: calculate used bytes
    st->used_bytes = 0;

    return whefs_rc.OK;
}


int whefs_test_insert_dummy_files( whefs_fs * fs )
{
    if( ! fs || ! fs->dev ) return whefs_rc.ArgError;
    int rc = whefs_rc.OK;
    whefs_file * F = 0;
    whefs_file_stats st;
    size_t nid = 0;
    char const * fname = "test_file_number_1";
    size_t szrc = 0;

#define INSERT(FN) \
    fname = FN; \
    F = whefs_fopen( fs, FN, "r+" );	   \
    assert( F && "whefs_fopen() failed!"); \
    nid = F->inode; \
    szrc = whefs_fwrite( F, 3, 1, "hi!" );				\
    WHEFS_DBG("fwrite result=%u",szrc); \
    rc = whefs_fstat( F, &st ); \
    WHEFS_DBG("fstat rc=%d\t F->inode = %u\tF->bytes = %u\tF->blocks = %u", rc, st.inode, st.bytes, st.blocks ); \
    rc = whefs_fclose( F ); \
    assert( (whefs_rc.OK == rc) && "whefs_fclose() failed!" ); \
    F = 0;

    INSERT("test_file_number_1");
    INSERT("test_file_number_2");
#undef INSERT

    whefs_inode ino;
    whio_dev * dev = 0;
#if 1
    ino.id = nid;
    whefs_inode_read( fs, &ino );
    whefs_inode_name_set( fs, &ino, "will be renamed");
    //whefs_inode_save( fs, &ino );
    dev = whefs_dev_for_inode( fs, ino.id, true );
    WHEFS_DBG("dev=%p",(void const *)dev);
    assert( dev && "opening of device for inode failed!" );
    nid = dev->api->write( dev, "Watson, come here!", 18 );
    WHEFS_DBG("write rc=%u", nid );
    nid = dev->api->write( dev, "\nComing, Alexander!", 19 );
    WHEFS_DBG("write rc=%u", nid );
    dev->api->finalize(dev);
#endif

#if 1
    //whefs_inode_next_free( fs, &ino, true );
    whefs_inode_read( fs, &ino );
    WHEFS_DBG("Trampling over inode #%u", ino.id );
    fname = "via whio_dev_inode";
    whefs_inode_name_set( fs, &ino, fname );
    dev = whefs_dev_for_inode( fs, ino.id, true );
    WHEFS_DBG("dev=%p",(void const *)dev);
    assert( dev && "couldn't re-open device!");
    dev->api->flush(dev);
    assert( dev && "opening of device for inode failed!" );
    size_t i = 0;
    size_t total = 0;
    for( ; i < 10; ++i )
    {
	nid = whio_dev_writef( dev, "Test #%02u", i );
	total += nid;
    }
    WHEFS_DBG("dev size=%u", whio_dev_size(dev) );
    dev->api->truncate( dev, 0 );
    dev->api->seek( dev, 30, SEEK_SET );
    WHEFS_DBG("dev size=%u", whio_dev_size(dev) );
    nid = dev->api->write( dev, "Stop saying that!!", 18 );
    total += nid;
    WHEFS_DBG("dev size=%u", whio_dev_size(dev) );
    dev->api->finalize(dev);

    F = whefs_fopen( fs, fname, "r+" );
    assert( F && "re-open of inode failed!" );
    dev = whefs_fdev( F );
    char const * str = "...And now a final word.";
    size_t slen = strlen(str);
    size_t dsize = whefs_fseek( F, 0, SEEK_END );
    WHEFS_DBG("F size=%u, slen=%u", dsize, slen );
    nid = whefs_fwrite( F, slen, 1, str );
    //WHEFS_DBG("whefs_fwrite() rc=%u", nid );
    assert( (1 == nid) && "write failed!" );
    dev->api->seek( dev, dsize + slen + 10, SEEK_SET );
    dev->api->write( dev, "!", 1 );
    //nid = whefs_fwrite( F, 1, 1, "!" );
    WHEFS_DBG("dev size=%u", whio_dev_size(dev) );
    whefs_fclose( F );
#endif

    return rc;
}

void whefs_setup_debug( FILE * ostream )
{
    whdbg_set_stream( ostream );
    whdbg_set_flags( WHEFS_DBG_F_DEFAULT );
}

const whefs_string whefs_string_init = whefs_string_init_m;

whefs_string * whefs_string_alloc()
{
    whefs_string * x = (whefs_string*)malloc(sizeof(whefs_string));
    if( x ) *x = whefs_string_init;
    return x;
}


int whefs_string_copy_cstring( whefs_string * tgt, char const * str )
{
    if( ! str || !tgt ) return whefs_rc.ArgError;
    size_t slen = 0;
    {
	char const * x = str;
	for( ; x && *x; ++x, ++slen ) {}
    }
    if( tgt->alloced > slen )
    {
	memset( tgt->string + slen, 0, tgt->alloced - slen );
	memcpy( tgt->string, str, slen );
	tgt->length = slen;
	return whefs_rc.OK;
    }
    if( (slen+1) >= UINT16_MAX ) return whefs_rc.RangeError;
    const whefs_string_size_t alen = slen + 1;
    if( alen < slen )
    { /* overflow! */
	return whefs_rc.RangeError;
    }
    char * xp = (char *) realloc( tgt->string, alen );
    if( ! xp ) return whefs_rc.AllocError;
    tgt->string = xp;
    tgt->alloced = alen;
    tgt->length = slen;
    memset( xp + slen, 0, alen - slen );
    memcpy( tgt->string, str, slen );
    return whefs_rc.OK;
}

int whefs_string_clear( whefs_string * tgt, bool clearChain )
{
    if( ! tgt ) return whefs_rc.ArgError;
    while( tgt )
    {
	whefs_string * n = tgt->next;
	free( tgt->string );
	*tgt = whefs_string_init;
	if( ! clearChain ) break;
	tgt = n;
    }
    return whefs_rc.OK;
}

int whefs_string_finalize( whefs_string * tgt, bool clearChain )
{
    if( ! tgt ) return whefs_rc.ArgError;
    while( tgt )
    {
	whefs_string * n = tgt->next;
	free( tgt->string );
	*tgt = whefs_string_init;
	free(tgt);
	if( ! clearChain ) break;
	tgt = n;
    }
    return whefs_rc.OK;
}

//int whefs_ls( whefs_fs * fs, char const * pattern, whefs_string * tgt,size_t * count  )
whefs_string * whefs_ls( whefs_fs * fs, char const * pattern, whefs_id_type * count  )
{
    if( ! fs ) return 0;
    const whefs_id_type nc = whefs_fs_options_get(fs)->inode_count;
    whefs_id_type id = 2; /* ID 1 is reserved for root node entry. */
    int rc = whefs_rc.OK;
    whefs_string * head = 0;
    whefs_string * str = 0;
    whefs_string * prev = 0;
    if( count ) *count = 0;
    whefs_string theString = whefs_string_init;
    for( ; id <= nc; ++id )
    {
#if WHEFS_FS_BITSET_CACHE_ENABLED
	if( ! WHEFS_ICACHE_IS_USED(fs,id) )
	{
	    continue;
	}
	//WHEFS_DBG("Cache says inode #%i is used.", i );
#endif
	rc = whefs_inode_name_get( fs, id, &theString );
	if( whefs_rc.OK != rc )
	{
	    //WHEFS_DBG("No! rc=%d",rc);
	    whefs_string_clear( &theString, false );
	    return head;
	}
	if(0) WHEFS_DBG("Here. id=%"WHEFS_ID_TYPE_PFMT" str.len=%u str=[%s]",
			id, theString.length, theString.string);
	if( pattern && *pattern && !whglob_matches( pattern, theString.string ) )
	{
	    continue;
	}
        if(1)
        {// make sure it's marked as used, or skip it
            uint32_t flagcheck = 0;
            whefs_inode_read_flags( fs, id, &flagcheck );
            if( ! (flagcheck & WHEFS_FLAG_Used) ) continue;
        }
	str = whefs_string_alloc();
	if( ! str ) return head;
	if( ! head ) head = str;
	*str = theString; theString = whefs_string_init; // take over ownership of theString.string
	if( prev ) prev->next = str;
	prev = str;
	if( count ) ++(*count);
    }
    whefs_string_clear( &theString, false );
    return head;
}

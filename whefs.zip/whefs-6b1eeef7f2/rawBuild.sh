#!/bin/sh
# Simple test to compare compile times between gcc and tcc without
# the overhead of Make interfering with the measurements.
CC=${1-tcc}
if [ tcc = $CC ]; then
    CFLAGS="-gb -bt 10 -Wunsupported"
else
    CFLAGS=
fi
CFLAGS="${CFLAGS} -I. -Wimplicit-function-declaration -Wwrite-strings -Wall -DWHIO_USE_STATIC_MALLOC=1"
echo "Using compiler: ${CC}"
echo "Flags: ${CFLAGS}"

${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whio.o whio.c
${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whio_dev.o whio_dev.c
${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whio_dev_FILE.o whio_dev_FILE.c
${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whio_dev_mem.o whio_dev_mem.c
${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whio_dev_subdev.o whio_dev_subdev.c
${CC} ${CFLAGS} -DWHIO_DEBUG_ENABLED=1 -c -o whprintf.o whprintf.c
ar crs libwhio.a whio.o whio_dev.o whio_dev_FILE.o whio_dev_mem.o whio_dev_subdev.o whprintf.o
${CC} ${CFLAGS} -c -o whefs.o whefs.c
${CC} ${CFLAGS} -c -o whefs_file.o whefs_file.c
${CC} ${CFLAGS} -c -o whefs_inode.o whefs_inode.c
${CC} ${CFLAGS} -c -o whefs_nodedev.o whefs_nodedev.c
${CC} ${CFLAGS} -c -o whbits.o whbits.c
${CC} ${CFLAGS} -c -o whdbg.o whdbg.c
${CC} ${CFLAGS} -c -o whglob.o whglob.c
ar crs libwhefs.a whefs.o whefs_file.o whefs_inode.o whefs_nodedev.o whbits.o whdbg.o whglob.o whio.o whio_dev.o whio_dev_FILE.o whio_dev_mem.o whio_dev_subdev.o whprintf.o

echo "Done!"

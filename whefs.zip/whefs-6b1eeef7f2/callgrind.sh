valgrind --tool=callgrind "$@" || exit
kcachegrind $(ls -1t callgrind.out* | head -1) &>/dev/null


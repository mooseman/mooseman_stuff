package parallisp;

import parallisp.types.PLFunction;
import parallisp.types.PLNil;
import parallisp.types.PLNumber;
import parallisp.types.PLPair;
import parallisp.types.PLValue;

public class PL {

	private static final PLValue TRUE = new PLNumber(1);
	private static final PLValue FALSE = PLNil.instance;

	public static PLValue eval(PLValue ast) {
		if (ast instanceof PLPair)
			return PL.apply(((PLPair) ast).first, ((PLPair) ast).last);
		else
			return ast;
	}

	public static PLValue apply(PLValue function, PLValue args) {
		if (function instanceof PLFunction)
			return ((PLFunction) function).apply(args);
		else
			throw new RuntimeException("Cannot apply " + function
					+ ", it is not a function!");
	}

	public static PLPair cons(PLValue a, PLValue b) {
		return new PLPair(a, b);
	}

	public static PLValue first(PLValue pair) {
		if (pair instanceof PLPair)
			return ((PLPair) pair).first;
		else
			throw new RuntimeException("Cannot take the first part of " + pair
					+ ", it is not a pair!");
	}

	public static PLValue last(PLValue pair) {
		if (pair instanceof PLPair)
			return ((PLPair) pair).last;
		else
			throw new RuntimeException("Cannot take the last part of " + pair
					+ ", it is not a pair!");
	}

	public static PLValue isNil(PLValue mightBeNil) {
		return mightBeNil == PLNil.instance ? TRUE : FALSE;
	}
}

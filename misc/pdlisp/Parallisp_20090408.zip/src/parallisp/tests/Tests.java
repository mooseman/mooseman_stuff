package parallisp.tests;

import parallisp.Interpreter;
import parallisp.PL;
import parallisp.PLUtils;

public class Tests {

	public static void main(String[] args) {
		assertEquals(eval("5"), 5);
		assertEquals(eval("(+ 1 2)"), 3);
		assertEquals(eval("(+ 1 2 3 2 1)"), 9);
		assertEquals(eval("(+ 1 (+ (+ 1 2) 3 (+ 5 5)))"), 17);
		
		//System.out.println(PLUtils.toString(Interpreter.parse("(+ 1 (+ 4 5))")));
		System.out.println("Success!");
	}

	static double eval(String code) {
		return PLUtils.asNumber(PL.eval(Interpreter.parse(code)));
	}

	static void assertEquals(double a, double b) {
		if (a != b)
			throw new RuntimeException("Failure! "+a + " != " + b);
	}
}

package parallisp.types;
public class PLNumber implements PLValue {
	public final double number;
	public PLNumber(double number) {
		this.number = number;
	}
}

package parallisp.types;


public class PLPair implements PLValue {

	public final PLValue first;
	public final PLValue last;

	public PLPair(PLValue first, PLValue last) {
		this.first = first;
		this.last = last;
	}
}

package parallisp.types;

public class PLNil implements PLValue {
	public static final PLNil instance = new PLNil();

	public String toString() {
		return "nil";
	}
}

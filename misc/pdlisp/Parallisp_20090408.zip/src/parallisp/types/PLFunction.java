package parallisp.types;

public abstract class PLFunction implements PLValue {
	public abstract PLValue apply(PLValue args);
}

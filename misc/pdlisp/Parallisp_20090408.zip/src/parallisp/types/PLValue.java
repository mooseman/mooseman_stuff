package parallisp.types;

public interface PLValue {
}

package parallisp;

import java.util.LinkedList;

import parallisp.types.PLFunction;
import parallisp.types.PLNil;
import parallisp.types.PLNumber;
import parallisp.types.PLValue;

public class Interpreter {
	private static final int NUMBER_TOKEN_TYPE = 0;
	private static final int OPEN_PAREN_TOKEN_TYPE = 1;
	private static final int CLOSE_PAREN_TOKEN_TYPE = 2;
	private static final int IDENTIFIER_TOKEN_TYPE = 3;

	/**
	 * The code currently being parsed
	 */
	static char[] code;
	/**
	 * The current index in the code string
	 */
	static int i;
	/**
	 * The current number token (only set for number tokens)
	 */
	static double numberToken;
	/**
	 * The current identifier token (only set for identifier tokens)
	 */
	static String identifierToken;
	/**
	 * The type of the current token
	 */
	static int tokenType;

	/**
	 * used for building strings
	 */
	static StringBuilder builder = new StringBuilder();

	/**
	 * Parses code into its abstract syntax tree
	 */
	public static PLValue parse(String codeString) {
		if (codeString == null || codeString.length() == 0)
			throw new RuntimeException("expression is empty!");
		code = codeString.trim().toCharArray();
		i = 0;
		scan();
		return parseExpression();
	}

	private static PLValue parseExpression() {
		switch (tokenType) {
		case OPEN_PAREN_TOKEN_TYPE:
			scan();
			PLValue result = parseExpression();
			if(tokenType == CLOSE_PAREN_TOKEN_TYPE)
				return result;
			else
			{
				LinkedList<PLValue> list = new LinkedList<PLValue>();
				list.add(result);
				scan();
				do {
					list.add(parseExpression());
					scan();
				} while (tokenType != CLOSE_PAREN_TOKEN_TYPE);
				return PLUtils.toList(list);
			}
		case CLOSE_PAREN_TOKEN_TYPE:
			throw new RuntimeException("Unbalanced parentheses!");
		case NUMBER_TOKEN_TYPE:
			return new PLNumber(numberToken);
		case IDENTIFIER_TOKEN_TYPE:
			if (identifierToken.equals("+")) {
				return new PLFunction() {
					public PLValue apply(PLValue args) {
						double result = 0;
						while (args != PLNil.instance) {
							result += PLUtils.asNumber(PL.eval(PL.first(args)));
							args = PL.last(args);
						}
						return new PLNumber(result);
					}

					public String toString() {
						return "+";
					}
				};
			}
		default:
			throw new RuntimeException("No token type!");
		}
	}

	private static void scan() {
		while (i < code.length && Character.isWhitespace(code[i]))
			i++;

		if (i >= code.length)
			throw new RuntimeException(
					"Syntax error, perhaps mismatched parentheses!");

		switch (code[i]) {
		case '(':
			tokenType = OPEN_PAREN_TOKEN_TYPE;
			i++;
			break;
		case ')':
			tokenType = CLOSE_PAREN_TOKEN_TYPE;
			i++;
			break;
		case '+':
			tokenType = IDENTIFIER_TOKEN_TYPE;
			identifierToken = ""+code[i];
			i++;
			break;
		default:
			builder.setLength(0);
			while (i < code.length && Character.isDigit(code[i]))
				builder.append(code[i++]);

			numberToken = Double.parseDouble(builder.toString());
			tokenType = NUMBER_TOKEN_TYPE;
		}
	}
}

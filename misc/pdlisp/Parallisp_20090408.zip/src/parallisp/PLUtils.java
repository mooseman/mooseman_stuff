package parallisp;

import java.util.List;

import parallisp.types.PLNil;
import parallisp.types.PLNumber;
import parallisp.types.PLPair;
import parallisp.types.PLValue;

public class PLUtils {
	public static double asNumber(PLValue number) {
		if (number instanceof PLNumber)
			return ((PLNumber) number).number;
		else
			throw new RuntimeException("Cannot use " + number + " as a number!");
	}

	public static PLValue toList(List<PLValue> list) {
		if (list.size() == 0)
			return PLNil.instance;
		else
			return PL.cons(list.get(0), toList(list.subList(1, list.size())));
	}

	public static String toString(PLValue value) {
		if (value instanceof PLPair)
			return "(" + toInnerString(value) + ")";
		else if (value instanceof PLNumber) {
			String string = Double.toString(((PLNumber) value).number);
			return string.endsWith(".0") ? string.replace(".0", "") : string;
		}
		return value.toString();
	}

	private static String toInnerString(PLValue value) {
		if (value instanceof PLPair) {
			String lastPart = toInnerString(PL.last(value));
			return toString(PL.first(value))
					+ (lastPart == null ? "" : " " + lastPart);
		} else
			return null;
	}
}